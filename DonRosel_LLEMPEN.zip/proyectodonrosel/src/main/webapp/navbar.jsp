<nav class="navbar navbar-expand-lg sticky-top shadow-sm" style="background-color: #506039;">
    <div class="container">
        <a class="navbar-brand fw-bold text-white" href="home">
            ☕ DON ROSEL
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link text-white" href="home">Inicio</a>
                </li>
            </ul>

            <div class="d-flex align-items-center">
                <a href="carrito.jsp" class="btn btn-outline-light position-relative border-0" style="background-color: #88471F;">
                    🛒 Mi Carrito
                    <c:if test="${not empty sessionScope.carrito}">
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                            ${sessionScope.carrito.size()}
                        </span>
                    </c:if>
                </a>
            </div>
        </div>
    </div>
</nav>