<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<!DOCTYPE html>
<html>
<head>
    <title>Don Rosel - ${p.nombre}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body style="background-color:#D9DCAF;">

<div class="container mt-5">
    <div class="row bg-white p-4 shadow rounded">

        <div class="col-md-6 text-center">
            <img src="img/productos/${p.imagen}.jpg"
                 class="img-fluid rounded shadow"
                 alt="${p.nombre}"
                 style="max-height: 450px; width: auto;">
        </div>

        <div class="col-md-6">
            <h2 style="color:#88471F;" class="fw-bold">${p.nombre}</h2>
            <p class="text-muted" style="font-size: 1.1rem;">${p.descripcion}</p>
            <hr>

            <form action="carrito" method="POST">
                <input type="hidden" name="id" value="${p.id}">
                <input type="hidden" name="nombreProducto" value="${p.nombre}">
                <input type="hidden" name="precioOculto" id="precioOculto" value="${p.precio}">

                <label class="fw-bold mb-2">Selecciona el peso:</label>
                <select name="pesoElegido" id="selectPeso" class="form-select mb-4" onchange="actualizarPrecio()">
                    <option value="250" data-precio="${p.precio}">
                        250g - S/ <fmt:formatNumber value="${p.precio}" minFractionDigits="2" maxFractionDigits="2"/>
                    </option>
                    <option value="500" data-precio="${p.precio * 1.8}">
                        500g - S/ <fmt:formatNumber value="${p.precio * 1.8}" minFractionDigits="2" maxFractionDigits="2"/>
                    </option>
                    <option value="1000" data-precio="${p.precio * 3.4}">
                        1kg - S/ <fmt:formatNumber value="${p.precio * 3.4}" minFractionDigits="2" maxFractionDigits="2"/>
                    </option>
                </select>

                <div class="mb-4">
                    <label class="fw-bold mb-2">Cantidad:</label>
                    <div class="d-flex align-items-center">
                        <input type="number" name="cantidadElegida" value="1" min="1"
                               max="${(p.stock != null && p.stock > 0) ? p.stock : 1}"
                               class="form-control" style="width:100px;">
                        <span class="ms-3 badge" style="background-color: #506039;">
                            ${(p.stock != null) ? p.stock : 0} disponibles
                        </span>
                    </div>
                </div>

                <div class="p-3 rounded mb-3" style="background-color: #f8f9fa; border-left: 5px solid #506039;">
                    <h3 id="precioDisplay" class="mb-0" style="color:#506039; font-weight: bold;">
                        Total: S/ <fmt:formatNumber value="${p.precio}" minFractionDigits="2" maxFractionDigits="2"/>
                    </h3>
                </div>

                <button type="submit" class="btn btn-lg w-100 shadow"
                        style="background-color:#88471F; color:white; font-weight: bold;">
                    AÑADIR AL CARRITO
                </button>
            </form>

            <div class="text-center mt-3">
                <a href="home" class="btn btn-link" style="color:#E29F61; text-decoration: none;">
                    ← Volver a la tienda
                </a>
            </div>
        </div>
    </div>
</div>

<script>
function actualizarPrecio() {
    const select = document.getElementById("selectPeso");
    const precio = select.options[select.selectedIndex].dataset.precio;

    // Actualiza el texto visual
    document.getElementById("precioDisplay").innerText =
        "Total: S/ " + parseFloat(precio).toFixed(2);

    // Actualiza el valor que se enviará al Servlet
    document.getElementById("precioOculto").value = precio;
}

// Inicializa el precio apenas carga la página
document.addEventListener("DOMContentLoaded", actualizarPrecio);
</script>

</body>
</html>
