<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>¡Gracias por tu compra! - Don Rosel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        :root {
            --russet: #88471F;
            --soldier-green: #506039;
            --cookies-cream: #D9DCAF;
        }
        body { background-color: #fcfaf7; font-family: 'Segoe UI', sans-serif; }
        .success-card {
            max-width: 600px;
            margin: 50px auto;
            border: none;
            border-radius: 20px;
            border-top: 8px solid var(--soldier-green);
        }
        .order-number {
            background-color: #f8f9fa;
            border: 2px dashed #dee2e6;
            padding: 10px;
            border-radius: 10px;
            display: inline-block;
        }
        .payment-box {
            background-color: #f1f8e9;
            border-radius: 15px;
            padding: 20px;
        }
        .btn-home { background-color: var(--russet); color: white; border-radius: 50px; }
        .btn-home:hover { background-color: #6d3919; color: white; }
        .btn-ws { background-color: #25D366; color: white; border-radius: 50px; }
    </style>
</head>
<body>

<div class="container">
    <div class="card success-card shadow-lg p-4 p-md-5 text-center">
        <div class="mb-4">
            <i class="bi bi-check-circle-fill text-success" style="font-size: 5rem;"></i>
        </div>

        <h2 class="fw-bold" style="color: var(--soldier-green);">¡Pedido Recibido con Éxito!</h2>
        <p class="lead text-secondary">Gracias por confiar en el aroma de **Don Rosel**.</p>

        <div class="order-number my-3">
            <span class="text-muted text-uppercase small d-block">Número de Orden</span>
            <span class="h4 fw-bold text-dark">#00${param.orden}</span>
        </div>

        <hr class="my-4">

        <div class="payment-box text-start mb-4">
            <h5 class="fw-bold mb-3"><i class="bi bi-wallet2 me-2"></i>¿Cómo completar tu pago?</h5>
            <p class="small text-muted mb-3">Como compraste como **invitado**, por favor realiza el pago para procesar tu envío:</p>

            <div class="d-flex align-items-center mb-2">
                <i class="bi bi-qr-code-scan fs-4 me-3 text-primary"></i>
                <div>
                    <strong>Yape / Plin:</strong> 995 905 532 <br>
                    <small class="text-muted">A nombre de: Rosel Administrador</small>
                </div>
            </div>
        </div>

        <div class="alert alert-light border small text-muted">
            <i class="bi bi-info-circle me-1"></i> Nuestro equipo te contactará por WhatsApp para confirmar la dirección de entrega.
        </div>

        <div class="d-grid gap-2 mt-4">
            <a href="https://api.whatsapp.com/send?phone=51995905532&text=Hola!%20Acabo%20de%20hacer%20el%20pedido%20%2300${param.orden}%20como%20invitado.%20Adjunto%20comprobante."
               target="_blank" class="btn btn-ws btn-lg fw-bold shadow-sm">
                <i class="bi bi-whatsapp me-2"></i>Enviar Comprobante
            </a>
            <a href="home" class="btn btn-home btn-lg fw-bold shadow-sm">
                <i class="bi bi-house-door me-2"></i>Volver al Inicio
            </a>
        </div>

        <p class="mt-4 small">
            <a href="registro" class="text-decoration-none" style="color: var(--russet);">
                ¿Quieres rastrear tus futuros pedidos? <strong>Regístrate aquí</strong>
            </a>
        </p>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>