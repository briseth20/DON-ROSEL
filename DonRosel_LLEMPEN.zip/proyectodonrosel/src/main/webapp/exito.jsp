<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>¡Compra Exitosa! - Don Rosel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .card-success { border-top: 5px solid #506039; }
        .btn-ws { background-color: #25d366; color: white; }
    </style>
</head>
<body class="bg-light">

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6 text-center">
                <div class="card shadow card-success p-4">
                    <h1 class="display-4 text-success">✔️</h1>
                    <h2 class="fw-bold">¡Gracias por tu compra!</h2>
                    <p class="text-muted">Tu pedido ha sido procesado con éxito.</p>

                    <div class="alert alert-info py-2">
                        <strong>Nro. de Pedido:</strong> #${param.idVenta}
                    </div>

                    <div class="d-grid gap-3 mt-4">
                        <a href="generarPDF?idVenta=${param.idVenta}" class="btn btn-danger btn-lg">
                            PDF: Descargar Boleta
                        </a>

                        <a href="https://wa.me/519XXXXXXXXX?text=Hola%20Don%20Rosel,%20mi%20pedido%20es%20el%20#${param.idVenta}"
                           target="_blank" class="btn btn-ws btn-lg">
                            Enviar comprobante por WhatsApp
                        </a>

                        <a href="home" class="btn btn-outline-secondary">Volver a la tienda</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>