<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Pedidos - Don Rosel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        :root {
            --russet: #88471F;
            --soldier-green: #506039;
            --crema-bg: #f4f1ea;
        }
        body { background-color: var(--crema-bg); font-family: 'Segoe UI', sans-serif; }
        .navbar-custom { background-color: var(--soldier-green); }

        /* Tarjetas de Pedido */
        .card-pedido {
            border: none;
            border-radius: 15px;
            border-left: 5px solid var(--russet);
            transition: transform 0.2s;
            background-color: #ffffff;
        }
        .card-pedido:hover { transform: translateY(-3px); }

        /* Tracking */
        .progress { height: 12px !important; border-radius: 10px; background-color: #e9ecef; }
        .step-label { font-size: 0.7rem; font-weight: bold; color: #6c757d; text-transform: uppercase; }

        .badge-status { border-radius: 50px; padding: 0.5em 1em; }
    </style>
</head>
<body>

<nav class="navbar navbar-dark navbar-custom shadow-sm mb-5">
    <div class="container">
        <a class="navbar-brand" href="home"><i class="bi bi-house-door-fill me-2"></i>TIENDA DON ROSEL</a>
        <div class="ms-auto text-white">
            <i class="bi bi-person-circle me-1"></i> ${usuario.nombre}
        </div>
    </div>
</nav>

<div class="container mb-5">
    <div class="row justify-content-center">
        <div class="col-md-11 col-lg-9">

            <div class="d-flex align-items-center mb-4">
                <h3 class="mb-0"><i class="bi bi-bag-check-fill me-2" style="color: var(--russet);"></i>Historial de Compras</h3>
            </div>

            <p class="text-muted mb-4">Consulta el estado de tus pedidos realizados y descarga tus comprobantes de pago.</p>

            <div class="card shadow-sm border-0">
                <div class="card-body p-4">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>Pedido</th>
                                    <th>Tracking</th>
                                    <th>Total</th>
                                    <th class="text-center">Estado</th>
                                    <th class="text-center">Boleta</th>
                                </tr>
                            </thead>
                            <tbody>
                                <c:forEach var="v" items="${misPedidos}">
                                    <tr>
                                        <td>
                                            <span class="fw-bold d-block">#${v.idVenta}</span>
                                            <small class="text-muted"><i class="bi bi-calendar3 me-1"></i> ${v.fecha}</small>
                                        </td>
                                        <td style="min-width: 240px;">
                                            <c:set var="progV" value="20"/>
                                            <c:choose>
                                                <c:when test="${v.estado == 'cancelado'}"><c:set var="progV" value="0"/></c:when>
                                                <c:when test="${v.estado == 'pendiente_pago'}"><c:set var="progV" value="40"/></c:when>
                                                <c:when test="${v.estado == 'pagado'}"><c:set var="progV" value="40"/></c:when>
                                                <c:when test="${v.estado == 'preparando'}"><c:set var="progV" value="60"/></c:when>
                                                <c:when test="${v.estado == 'enviado'}"><c:set var="progV" value="80"/></c:when>
                                                <c:when test="${v.estado == 'entregado'}"><c:set var="progV" value="100"/></c:when>
                                            </c:choose>
                                            <div class="progress mb-1">
                                                <div class="progress-bar bg-success progress-bar-striped progress-bar-animated"
                                                     role="progressbar" style="width: ${progV}%"></div>
                                            </div>
                                            <div class="d-flex justify-content-between step-label">
                                                <span class="${progV >= 20 ? 'text-dark' : ''}">Recibido</span>
                                                <span class="${progV >= 40 ? 'text-dark' : ''}">Listo pago</span>
                                                <span class="${progV >= 60 ? 'text-dark' : ''}">Preparando</span>
                                                <span class="${progV >= 80 ? 'text-dark' : ''}">En camino</span>
                                                <span class="${progV == 100 ? 'text-success' : ''}">Listo recoger</span>
                                            </div>
                                        </td>
                                        <td class="fw-bold text-dark">
                                            S/ <fmt:formatNumber value="${v.montoTotal}" minFractionDigits="2"/>
                                        </td>
                                        <td class="text-center">
                                            <c:choose>
                                                <c:when test="${v.estado == 'cancelado'}">
                                                    <span class="badge badge-status bg-danger shadow-sm">CANCELADO</span>
                                                </c:when>
                                                <c:otherwise>
                                                    <span class="badge badge-status bg-secondary shadow-sm">
                                                        ${v.estado}
                                                    </span>
                                                </c:otherwise>
                                            </c:choose>
                                        </td>
                                        <td class="text-center">
                                            <a href="GenerarPDFServlet?idVenta=${v.idVenta}" target="_blank" class="btn btn-sm btn-outline-danger rounded-circle">
                                                <i class="bi bi-file-pdf"></i>
                                            </a>
                                        </td>
                                    </tr>
                                </c:forEach>

                                <c:if test="${empty misPedidos}">
                                    <tr>
                                        <td colspan="5" class="text-center py-5">
                                            <i class="bi bi-cart-x fs-1 text-muted"></i>
                                            <p class="text-muted mt-2">Aún no tienes compras finalizadas.</p>
                                            <a href="index.jsp" class="btn btn-primary rounded-pill px-4">Ir a la Tienda</a>
                                        </td>
                                    </tr>
                                </c:if>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
