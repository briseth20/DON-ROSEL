<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Don Rosel - Registro de Cliente</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        :root { --russet: #88471F; --soldier: #506039; }
        body { background-color: #fcfaf7; height: 100vh; display: flex; align-items: center; }
        .reg-card { border: none; border-radius: 20px; max-width: 450px; width: 100%; border-top: 6px solid var(--russet); }
        .form-control:focus { border-color: var(--russet); box-shadow: 0 0 0 0.25rem rgba(136, 71, 31, 0.1); }
    </style>
</head>
<body>

<div class="container d-flex justify-content-center px-3">
    <div class="card reg-card shadow-lg p-4 p-md-5 bg-white">
        <div class="text-center mb-4">
            <h3 class="fw-bold" style="color: var(--soldier);">Crea tu cuenta</h3>
            <p class="text-muted small">Únete a Don Rosel y rastrea tus pedidos</p>
        </div>

        <%-- Alerta de Error en Registro --%>
        <c:if test="${param.error == '1'}">
            <div class="alert alert-warning small py-2">
                <i class="bi bi-info-circle me-1"></i> El correo ya está registrado o hay un error.
            </div>
        </c:if>

        <form action="registro" method="POST">
            <div class="mb-3">
                <label class="form-label small fw-bold">Nombre Completo</label>
                <input type="text" name="txtnombre" class="form-control bg-light" placeholder="Juan Perez" required>
            </div>

            <div class="mb-3">
                <label class="form-label small fw-bold">Correo Electrónico</label>
                <input type="email" name="txtemail" class="form-control bg-light" placeholder="correo@ejemplo.com" required>
            </div>

            <div class="mb-4">
                <label class="form-label small fw-bold">Contraseña</label>
                <input type="password" name="txtpass" class="form-control bg-light" placeholder="Mínimo 6 caracteres" required>
            </div>

            <button type="submit" class="btn btn-success w-100 fw-bold p-2 mb-3 shadow-sm rounded-pill">
                REGISTRARME AHORA
            </button>

            <div class="text-center">
                <a href="login.jsp" class="text-muted small text-decoration-none">
                    ¿Ya tienes cuenta? <span class="fw-bold" style="color: var(--russet);">Inicia sesión</span>
                </a>
            </div>
        </form>
    </div>
</div>

</body>
</html>