<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Don Rosel - Mi Carrito</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        :root {
            --russet: #88471F;
            --soldier-green: #506039;
            --cookies-cream: #D9DCAF;
            --earth-yellow: #E29F61;
        }
        body { background-color: var(--cookies-cream); font-family: 'Segoe UI', sans-serif; }
        .cart-container { border-radius: 20px; border: none; overflow: hidden; }
        .table thead { background-color: var(--soldier-green); color: white; }
        .btn-whatsapp { background-color: #25D366; color: white; font-weight: bold; border: none; transition: 0.3s; }
        .btn-whatsapp:hover { background-color: #128C7E; color: white; transform: scale(1.02); }
        .btn-pay { background-color: var(--russet); color: white; font-weight: bold; border: none; transition: 0.3s; }
        .btn-pay:hover { background-color: #6d3919; color: white; transform: scale(1.02); }
        .btn-guest { background-color: #495057; color: white; font-weight: bold; border: none; }
        .btn-guest:hover { background-color: #343a40; color: white; }
        .tracking-box { background-color: #fff3cd; border-left: 4px solid var(--earth-yellow); border-radius: 10px; }
        .select-pago { border: 2px solid var(--earth-yellow); border-radius: 10px; padding: 10px; font-weight: 600; color: var(--russet); }
    </style>
</head>
<body>

<div class="container mt-5 mb-5">
    <div class="card cart-container shadow-lg p-4 bg-white">

        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold m-0" style="color: var(--russet);">
                <i class="bi bi-cart-check-fill me-2"></i>Mi Pedido
            </h2>
            <c:if test="${not empty param.idReserva}">
                <span class="badge bg-warning text-dark p-2">
                    <i class="bi bi-info-circle"></i> Pagando Reserva #${param.idReserva}
                </span>
            </c:if>
            <a href="carrito?accion=vaciar" class="btn btn-sm btn-outline-danger rounded-pill px-3">
                <i class="bi bi-trash3 me-1"></i> Vaciar
            </a>
        </div>

        <div class="table-responsive">
            <table class="table align-middle" id="tablaCarrito">
                <thead>
                    <tr>
                        <th style="border-radius: 10px 0 0 0;">Producto</th>
                        <th>Presentación</th>
                        <th>Precio Unit.</th>
                        <th class="text-center">Cant.</th>
                        <th>Subtotal</th>
                        <th class="text-center" style="border-radius: 0 10px 0 0;">Acción</th>
                    </tr>
                </thead>
                <tbody>
                    <c:forEach var="item" items="${sessionScope.carrito}">
                        <tr>
                            <td><div class="fw-bold" style="color: var(--soldier-green);">${item.nombre}</div></td>
                            <td><span class="badge bg-light text-dark border px-3">${item.peso}</span></td>
                            <td>S/ <fmt:formatNumber value="${item.precioUnitario}" minFractionDigits="2"/></td>
                            <td class="text-center"><span class="badge rounded-pill bg-secondary px-3">${item.cantidad}</span></td>
                            <td class="fw-bold text-dark">S/ <fmt:formatNumber value="${item.precioUnitario * item.cantidad}" minFractionDigits="2"/></td>
                            <td class="text-center">
                                <a href="carrito?accion=eliminar&id=${item.idProducto}" class="text-danger fs-5"><i class="bi bi-x-circle-fill"></i></a>
                            </td>
                        </tr>
                    </c:forEach>
                    <c:if test="${empty sessionScope.carrito}">
                        <tr id="filaVacia">
                            <td colspan="6" class="text-center py-5 text-muted">
                                <i class="bi bi-cup-hot fs-1 d-block mb-3" style="color: var(--earth-yellow);"></i>
                                <p class="mb-0">Parece que tu carrito está vacío.</p>
                                <a href="index.jsp" class="btn btn-link text-decoration-none" style="color: var(--russet);">Explorar catálogo</a>
                            </td>
                        </tr>
                    </c:if>
                </tbody>
                <tfoot class="table-light">
                    <tr>
                        <td colspan="4" class="text-end fw-bold fs-5 p-3">TOTAL ESTIMADO:</td>
                        <td id="totalMonto" class="fw-bold text-success fs-4 p-3">
                            S/ <fmt:formatNumber value="${sessionScope.total != null ? sessionScope.total : 0.00}" minFractionDigits="2"/>
                        </td>
                        <td></td>
                    </tr>
                </tfoot>
            </table>
        </div>

        <div class="row mt-4 gy-3">
            <div class="col-md-4">
                <a href="index.jsp" class="btn btn-outline-dark w-100 fw-bold rounded-pill p-3">
                    <i class="bi bi-arrow-left me-2"></i>SEGUIR COMPRANDO
                </a>
            </div>
            <div class="col-md-4">
                <button type="button" onclick="enviarWhatsApp()" class="btn btn-whatsapp w-100 fw-bold rounded-pill p-3 shadow-sm">
                    <i class="bi bi-whatsapp me-2"></i>ENVIAR POR WHATSAPP
                </button>
            </div>

            <div class="col-md-4">
                <form action="ProcesarVentaServlet" method="POST">
                    <c:if test="${not empty param.idReserva}">
                        <input type="hidden" name="idReserva" value="${param.idReserva}">
                    </c:if>
                    <div class="mb-2">
                        <input type="text" name="nombre" class="form-control form-control-sm" placeholder="Tu nombre" required value="${sessionScope.usuario.nombre}">
                    </div>
                    <div class="mb-2">
                        <input type="text" name="telefono" class="form-control form-control-sm" placeholder="Teléfono" required>
                    </div>
                    <div class="mb-2">
                        <input type="text" name="direccion" class="form-control form-control-sm" placeholder="Dirección de entrega" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-bold text-muted">Selecciona tu método de pago:</label>
                        <select name="metodo_pago" class="form-select select-pago shadow-sm" required>
                            <option value="" disabled selected>Elegir método...</option>
                            <option value="yape">🟣 Yape</option>
                            <option value="plin">🔵 Plin</option>
                            <option value="tarjeta">💳 Tarjeta (Crédito/Débito)</option>
                            <option value="efectivo">💵 Efectivo</option>
                        </select>
                    </div>

                    <button type="submit" class="btn ${not empty sessionScope.usuario ? 'btn-pay' : 'btn-guest'} w-100 fw-bold rounded-pill p-3 shadow-sm">
                        <i class="bi bi-bag-check-fill me-2"></i> FINALIZAR COMPRA
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function enviarWhatsApp() {
    let telefono = "51995905532";
    let totalElemento = document.getElementById("totalMonto");
    let totalTexto = totalElemento ? totalElemento.innerText.trim() : "S/ 0.00";
    if (totalTexto.includes("0.00") || document.getElementById("filaVacia")) {
        alert("Agrega productos antes de enviar el pedido.");
        return;
    }
    let mensaje = "☕ *PEDIDO DON ROSEL* ☕%0A%0A";
    let filas = document.querySelectorAll("#tablaCarrito tbody tr");
    filas.forEach(fila => {
        let celdas = fila.querySelectorAll("td");
        if (celdas.length >= 5) {
            let nombre = celdas[0].innerText.trim();
            let cant = celdas[3].innerText.trim();
            let sub = celdas[4].innerText.trim();
            mensaje += `• *${nombre}* x${cant} - ${sub}%0A`;
        }
    });
    mensaje += `%0A*TOTAL: ${totalTexto}*%0A%0A_¿Me podrían confirmar el stock?_`;
    window.open("https://api.whatsapp.com/send?phone=" + telefono + "&text=" + mensaje, "_blank");
}
</script>
</body>
</html>
