<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Admin - Don Rosel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        :root { --russet: #88471F; --soldier-green: #506039; --gold-special: #D4AF37; }
        body { background-color: #f8f9fa; font-family: 'Segoe UI', sans-serif; }
        .navbar-admin { background-color: var(--russet) !important; }
        .btn-green { background-color: var(--soldier-green); color: white; border: none; }
        .nav-tabs .nav-link.active { color: var(--soldier-green); border-bottom: 3px solid var(--soldier-green); font-weight: bold; }
    </style>
</head>
<body>
<p>DEBUG: Productos en lista: ${productosTotal.size()}</p>
<nav class="navbar navbar-expand-lg navbar-dark navbar-admin shadow-sm mb-4">
    <div class="container">
        <a class="navbar-brand" href="panelAdmin"><i class="bi bi-gear-fill me-2"></i>PANEL CONTROL | DON ROSEL</a>
        <div class="ms-auto text-white">
            <%-- Saludo al admin logueado --%>
            <span class="me-3">Bienvenido, <strong>${usuario.nombre}</strong></span>
            <a href="login?accion=salir" class="btn btn-outline-light btn-sm rounded-pill">Salir</a>
        </div>
    </div>
</nav>

<div class="container mb-5">
    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <small class="text-muted">Ventas web</small>
                    <div class="fs-4 fw-bold text-success">S/ <fmt:formatNumber value="${dashboard.ventasWeb}" minFractionDigits="2"/></div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <small class="text-muted">Ventas presenciales</small>
                    <div class="fs-4 fw-bold text-primary">S/ <fmt:formatNumber value="${dashboard.ventasPresenciales}" minFractionDigits="2"/></div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <small class="text-muted">Total combinado</small>
                    <div class="fs-4 fw-bold">S/ <fmt:formatNumber value="${dashboard.totalCombinado}" minFractionDigits="2"/></div>
                </div>
            </div>
        </div>
    </div>

    <div class="d-flex justify-content-end mb-3">
        <a href="ExportarExcelServlet" class="btn btn-outline-success btn-sm rounded-pill">
            <i class="bi bi-file-earmark-excel me-1"></i> Exportar Excel (Ventas y Reservas)
        </a>
    </div>

    <div class="card border-0 shadow-sm mb-4">
        <div class="card-header text-white" style="background: var(--russet)">
            Venta Presencial (Manual)
        </div>
        <div class="card-body">
            <form action="panelAdmin" method="POST" class="row g-2 align-items-end">
                <input type="hidden" name="accion" value="registrarVentaExterna">
                <div class="col-md-4">
                    <label class="form-label small fw-bold">Producto</label>
                    <select name="idProducto" class="form-select form-select-sm" id="productoPresencial" required onchange="actualizarTotalPresencial()">
                        <c:forEach var="p" items="${productosTotal}">
                            <option value="${p.id}" data-precio="${p.precio}">${p.nombre} - S/ ${p.precio}</option>
                        </c:forEach>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label small fw-bold">Cantidad</label>
                    <input type="number" name="cantidad" id="cantidadPresencial" class="form-control form-control-sm" min="1" value="1" required oninput="actualizarTotalPresencial()" onchange="actualizarTotalPresencial()" onkeyup="actualizarTotalPresencial()">
                </div>
                <div class="col-md-2">
                    <label class="form-label small fw-bold">Metodo</label>
                    <select name="metodoPago" class="form-select form-select-sm" required>
                        <option value="efectivo">Efectivo</option>
                        <option value="yape">Yape</option>
                        <option value="tarjeta">Tarjeta</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-bold">Cliente (opcional)</label>
                    <input type="text" name="nombreTitular" class="form-control form-control-sm" placeholder="Nombre">
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-bold">Telefono</label>
                    <input type="text" name="telefono" class="form-control form-control-sm" placeholder="999 999 999">
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-bold">Direccion</label>
                    <input type="text" name="direccion" class="form-control form-control-sm" placeholder="Direccion de entrega">
                </div>
                <div class="col-md-2">
                    <label class="form-label small fw-bold">Total</label>
                    <div class="form-control form-control-sm bg-light" id="totalPresencial" style="color:#000; min-height: 31px; display:flex; align-items:center;">S/ 0.00</div>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-sm btn-green w-100">
                        <i class="bi bi-check-lg"></i> Registrar
                    </button>
                </div>
            </form>
        </div>
    </div>

    <ul class="nav nav-tabs mb-4 border-0" id="adminTabs" role="tablist">
        <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#stock">Inventario</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#ventas">Ventas y Pagos</button></li>
        <li class="nav-item">
            <button class="nav-link position-relative" data-bs-toggle="tab" data-bs-target="#reservas">
                Reservas Especiales
                <c:if test="${not empty listaReservas}">
                    <span class="badge rounded-pill bg-danger">${listaReservas.size()}</span>
                </c:if>
            </button>
        </li>
    </ul>

    <div class="tab-content shadow-sm rounded-3 bg-white">

        <%-- TAB 1: INVENTARIO --%>
        <div class="tab-pane fade show active" id="stock">
            <div class="card border-0">
                <div class="card-header text-white" style="background: var(--soldier-green)">Gestión de Productos</div>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr><th>Producto</th><th>Precio</th><th>Stock</th><th>Estado</th><th class="text-center">Acciones</th></tr>
                        </thead>
                        <tbody>
                            <c:forEach var="p" items="${productosTotal}">
                                <tr>
                                    <td class="ps-4"><strong>${p.nombre}</strong></td>
                                    <td>S/ ${p.precio}</td>
                                    <td>
                                        <form action="panelAdmin" method="POST" class="d-flex" style="max-width: 120px;">
                                            <input type="hidden" name="id" value="${p.id}">
                                            <input type="number" name="nuevoStock" value="${p.stock}" class="form-control form-control-sm me-1">
                                            <button type="submit" name="accion" value="actualizarStock" class="btn btn-sm btn-green"><i class="bi bi-save"></i></button>
                                        </form>
                                    </td>
                                    <td><span class="badge ${p.esVisible ? 'bg-success' : 'bg-secondary'}">${p.esVisible ? 'Visible' : 'Oculto'}</span></td>
                                    <td class="text-center">
                                        <a href="panelAdmin?accion=cambiarEstado&id=${p.id}&estado=${!p.esVisible}" class="btn btn-sm btn-outline-dark rounded-pill">Cambiar</a>
                                    </td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <%-- TAB 2: VENTAS --%>
        <div class="tab-pane fade" id="ventas">
            <div class="card border-0">
                <div class="card-header text-white" style="background: var(--russet)">Validación de Pagos</div>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr><th>ID</th><th>Metodo</th><th>Monto</th><th>Estado Tracking</th><th class="text-center">Boleta</th></tr>
                        </thead>
                        <tbody>
                            <c:forEach var="v" items="${historialVentas}">
                                <tr>
                                    <td class="ps-4">#${v.idVenta}</td>
                                    <td><span class="badge bg-info text-dark">${v.metodoPago}</span></td>
                                    <td class="fw-bold text-success">S/ ${v.montoTotal}</td>
                                    <td>
                                        <form action="panelAdmin" method="POST" class="d-flex">
                                            <input type="hidden" name="idVenta" value="${v.idVenta}">
                                            <input type="hidden" name="accion" value="actualizarEstadoPedido">
                                            <select name="nuevoEstado" class="form-select form-select-sm me-1">
                                                <option value="pendiente_pago" ${v.estado == 'pendiente_pago' ? 'selected' : ''}>Listo para pago</option>
                                                <option value="pagado" ${v.estado == 'pagado' ? 'selected' : ''}>Pagado</option>
                                                <option value="preparando" ${v.estado == 'preparando' ? 'selected' : ''}>Preparando</option>
                                                <option value="enviado" ${v.estado == 'enviado' ? 'selected' : ''}>En camino</option>
                                                <option value="entregado" ${v.estado == 'entregado' ? 'selected' : ''}>Listo para recoger</option>
                                                <option value="cancelado" ${v.estado == 'cancelado' ? 'selected' : ''}>Cancelado</option>
                                            </select>
                                            <button type="submit" class="btn btn-sm btn-green"><i class="bi bi-check-lg"></i></button>
                                        </form>
                                    </td>
                                    <td class="text-center">
                                        <a href="GenerarPDFServlet?idVenta=${v.idVenta}" target="_blank" class="btn btn-sm btn-danger rounded-circle"><i class="bi bi-file-pdf"></i></a>
                                        <form action="panelAdmin" method="POST" class="d-inline-block ms-1">
                                            <input type="hidden" name="accion" value="cancelarVenta">
                                            <input type="hidden" name="idVenta" value="${v.idVenta}">
                                            <button type="submit" class="btn btn-sm btn-outline-secondary rounded-circle" title="Cancelar">
                                                <i class="bi bi-x-lg"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <%-- TAB 3: RESERVAS --%>
        <div class="tab-pane fade" id="reservas">
            <div class="card border-0">
                <div class="card-header bg-dark text-white">Validación de Reservas</div>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr><th>ID</th><th>Cliente</th><th>Producto</th><th>Estado</th><th class="text-center">Acción</th><th class="text-center">Boleta</th></tr>
                        </thead>
                        <tbody>
                            <c:forEach var="res" items="${listaReservas}">
                                <tr>
                                    <td class="ps-4">#${res.idReserva}</td>
                                    <td>${res.usuario.nombre}</td>
                                    <td><span class="badge bg-secondary">${res.producto.nombre}</span></td>
                                    <td>
                                        <span class="badge ${res.estado == 'PENDIENTE' ? 'bg-warning text-dark' : 'bg-success'}">
                                            ${res.estado}
                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <c:if test="${res.estado == 'PENDIENTE'}">
                                            <form action="panelAdmin" method="POST" class="d-inline-flex me-2">
                                                <input type="hidden" name="accion" value="actualizarEstadoReserva">
                                                <input type="hidden" name="idReserva" value="${res.idReserva}">
                                                <input type="hidden" name="nuevoEstado" value="LISTO_PARA_PAGO">
                                                <button type="submit" class="btn btn-sm btn-warning text-dark">
                                                    <i class="bi bi-check2-circle"></i> Confirmar
                                                </button>
                                            </form>
                                        </c:if>
                                        <form action="panelAdmin" method="POST" class="d-inline-flex">
                                            <input type="hidden" name="accion" value="actualizarEstadoReserva">
                                            <input type="hidden" name="idReserva" value="${res.idReserva}">
                                            <select name="nuevoEstado" class="form-select form-select-sm me-1">
                                                <option value="PENDIENTE" ${res.estado == 'PENDIENTE' ? 'selected' : ''}>Pendiente</option>
                                                <option value="LISTO_PARA_PAGO" ${res.estado == 'LISTO_PARA_PAGO' ? 'selected' : ''}>Listo para pago</option>
                                                <option value="PAGADO" ${res.estado == 'PAGADO' ? 'selected' : ''}>Pagado</option>
                                                <option value="PREPARANDO" ${res.estado == 'PREPARANDO' ? 'selected' : ''}>Preparando</option>
                                                <option value="EN_CAMINO" ${res.estado == 'EN_CAMINO' ? 'selected' : ''}>En camino</option>
                                                <option value="LISTO_PARA_RECOGER" ${res.estado == 'LISTO_PARA_RECOGER' ? 'selected' : ''}>Listo para recoger</option>
                                                <option value="CANCELADO" ${res.estado == 'CANCELADO' ? 'selected' : ''}>Cancelado</option>
                                                <option value="COMPLETADO" ${res.estado == 'COMPLETADO' ? 'selected' : ''}>Completado</option>
                                            </select>
                                            <button type="submit" class="btn btn-sm btn-success text-white"><i class="bi bi-save"></i></button>
                                        </form>
                                    </td>
                                    <td class="text-center">
                                        <a href="GenerarReservaPDFServlet?idReserva=${res.idReserva}" target="_blank" class="btn btn-sm btn-outline-danger rounded-circle">
                                            <i class="bi bi-file-pdf"></i>
                                        </a>
                                        <form action="panelAdmin" method="POST" class="d-inline-block ms-1">
                                            <input type="hidden" name="accion" value="cancelarReserva">
                                            <input type="hidden" name="idReserva" value="${res.idReserva}">
                                            <button type="submit" class="btn btn-sm btn-outline-secondary rounded-circle" title="Cancelar">
                                                <i class="bi bi-x-lg"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            </c:forEach>
                            <c:if test="${empty listaReservas}">
                                <tr><td colspan="6" class="text-center py-5">No hay reservas registradas.</td></tr>
                            </c:if>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Calcula el total de la venta presencial con el precio del producto.
function actualizarTotalPresencial() {
    const select = document.getElementById("productoPresencial");
    const cantidad = document.getElementById("cantidadPresencial");
    const total = document.getElementById("totalPresencial");
    if (!select || !cantidad || !total) return;
    const option = select.options[select.selectedIndex];
    if (!option) {
        total.value = "S/ 0.00";
        return;
    }
    const raw = option.dataset.precio || "";
    let precio = parseFloat(String(raw).replace(",", ".").trim());
    if (!isFinite(precio)) {
        const text = option.textContent || "";
        const match = text.match(/S\/\s*([0-9]+(?:[.,][0-9]+)?)/);
        precio = match ? parseFloat(match[1].replace(",", ".")) : 0;
    }
    const qty = parseInt(cantidad.value || "0", 10) || 0;
    const monto = isFinite(precio) ? (precio * qty) : 0;
    total.textContent = "S/ " + monto.toFixed(2);
}
const productoSelect = document.getElementById("productoPresencial");
const cantidadInput = document.getElementById("cantidadPresencial");
productoSelect?.addEventListener("change", actualizarTotalPresencial);
productoSelect?.addEventListener("input", actualizarTotalPresencial);
cantidadInput?.addEventListener("input", actualizarTotalPresencial);
document.addEventListener("DOMContentLoaded", actualizarTotalPresencial);
window.addEventListener("load", actualizarTotalPresencial);
setTimeout(actualizarTotalPresencial, 0);
setInterval(actualizarTotalPresencial, 250);
</script>
</body>
</html>
