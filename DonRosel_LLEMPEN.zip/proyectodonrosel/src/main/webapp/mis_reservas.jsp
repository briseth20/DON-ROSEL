<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Don Rosel - Mis Reservas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        :root {
            --cafe-oscuro: #3e2723;
            --cafe-medio: #5d4037;
            --dorado: #d4af37;
            --crema: #fff9f0;
        }
        body { background-color: var(--crema); font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .navbar { background-color: var(--cafe-oscuro) !important; border-bottom: 3px solid var(--dorado); }
        .card { border: none; border-radius: 15px; overflow: hidden; }
        .card-header { background-color: var(--cafe-medio); color: white; font-weight: bold; }

        /* Estilos de Tracking */
        .progress { height: 12px; border-radius: 10px; background-color: #dee2e6; }
        .step-label { font-size: 0.7rem; font-weight: 700; margin-top: 6px; text-transform: uppercase; }
        .text-active { color: var(--cafe-oscuro) !important; text-decoration: underline; }

        /* Botones y Badges */
        .btn-gold { background-color: var(--dorado); color: var(--cafe-oscuro); font-weight: bold; border-radius: 50px; transition: 0.3s; }
        .btn-gold:hover { background-color: var(--cafe-oscuro); color: var(--dorado); transform: scale(1.02); }
        .badge-status { font-size: 0.75rem; padding: 0.6em 1em; border-radius: 50px; }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark shadow mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold" href="home">
            <i class="bi bi-cup-hot-fill me-2"></i>Don Rosel
        </a>
        <div class="d-flex">
            <a href="home" class="btn btn-outline-light btn-sm rounded-pill">
                <i class="bi bi-house-door me-1"></i> Inicio
            </a>
        </div>
    </div>
</nav>

<div class="container mb-5">
    <div class="row justify-content-center">
        <div class="col-xl-10">
            <div class="card shadow-lg">
                <div class="card-header py-3">
                    <h5 class="mb-0 text-center"><i class="bi bi-truck me-2"></i>MI TRACKING DE PEDIDOS ESPECIALES</h5>
                </div>
                <div class="card-body p-4">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>Detalle del Producto</th>
                                    <th>Progreso del Envío</th>
                                    <th>Precio</th>
                                    <th class="text-center">Estado / Acción</th>
                                    <th class="text-center">Boleta</th>
                                </tr>
                            </thead>
                            <tbody>
                                <c:forEach var="res" items="${reservas}">
                                    <tr>
                                        <td>
                                            <span class="fw-bold d-block text-uppercase">${res.producto.nombre}</span>
                                            <span class="badge bg-dark" style="font-size: 0.65rem;">ID: #${res.idReserva}</span>
                                        </td>
                                        <td>
                                            <%-- Lógica de Progreso --%>
                                            <c:set var="pct" value="20"/>
                                            <c:choose>
                                                <c:when test="${res.estado == 'LISTO_PARA_PAGO'}"><c:set var="pct" value="40"/></c:when>
                                                <c:when test="${res.estado == 'PAGADO'}"><c:set var="pct" value="40"/></c:when>
                                                <c:when test="${res.estado == 'PREPARANDO'}"><c:set var="pct" value="60"/></c:when>
                                                <c:when test="${res.estado == 'EN_CAMINO'}"><c:set var="pct" value="80"/></c:when>
                                                <c:when test="${res.estado == 'LISTO_PARA_RECOGER'}"><c:set var="pct" value="90"/></c:when>
                                                <c:when test="${res.estado == 'COMPLETADO'}"><c:set var="pct" value="100"/></c:when>
                                            </c:choose>

                                            <div class="px-2">
                                                <c:if test="${res.estado == 'CANCELADO'}">
                                                    <c:set var="pct" value="0"/>
                                                </c:if>
                                                <div class="progress shadow-sm">
                                                    <div class="progress-bar progress-bar-striped progress-bar-animated
                                                        ${res.estado == 'COMPLETADO' ? 'bg-success' : 'bg-warning'}"
                                                        style="width: ${pct}%"></div>
                                                </div>
                                                <div class="d-flex justify-content-between step-label">
                                                    <span class="${res.estado == 'PENDIENTE' ? 'text-active' : 'text-muted'}">Recibido</span>
                                                    <span class="${res.estado == 'LISTO_PARA_PAGO' || res.estado == 'PAGADO' ? 'text-active' : 'text-muted'}">Listo pago</span>
                                                    <span class="${res.estado == 'PREPARANDO' ? 'text-active' : 'text-muted'}">Preparando</span>
                                                    <span class="${res.estado == 'EN_CAMINO' ? 'text-active' : 'text-muted'}">En camino</span>
                                                    <span class="${res.estado == 'LISTO_PARA_RECOGER' || res.estado == 'COMPLETADO' ? 'text-success fw-bold' : 'text-muted'}">Listo recoger</span>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="fw-bold text-dark">S/ ${res.producto.precio}</td>
                                        <td class="text-center">
                                            <c:choose>
                                                <c:when test="${res.estado == 'PENDIENTE'}">
                                                    <span class="badge bg-secondary badge-status shadow-sm">
                                                        <i class="bi bi-clock-history me-1"></i> POR CONFIRMAR
                                                    </span>
                                                </c:when>
                                                <c:when test="${res.estado == 'LISTO_PARA_PAGO'}">
                                                    <a href="${pageContext.request.contextPath}/carrito?accion=AgregarCarrito&id=${res.producto.id}&idReserva=${res.idReserva}"
                                                       class="btn btn-gold btn-sm w-100 shadow-sm">
                                                        <i class="bi bi-credit-card-2-back me-1"></i> PAGAR AHORA
                                                    </a>
                                                </c:when>
                                                <c:when test="${res.estado == 'PAGADO'}">
                                                    <span class="badge bg-success badge-status shadow-sm">
                                                        <i class="bi bi-check2-circle me-1"></i> PAGADO
                                                    </span>
                                                </c:when>
                                                <c:when test="${res.estado == 'CANCELADO'}">
                                                    <span class="badge bg-danger badge-status shadow-sm">
                                                        <i class="bi bi-x-circle me-1"></i> CANCELADO
                                                    </span>
                                                </c:when>
                                                <c:otherwise>
                                                    <span class="badge bg-white text-dark border badge-status shadow-sm text-uppercase">
                                                        <i class="bi bi-check2-circle me-1"></i> ${res.estado}
                                                    </span>
                                                </c:otherwise>
                                            </c:choose>
                                        </td>
                                        <td class="text-center">
                                            <a href="GenerarReservaPDFServlet?idReserva=${res.idReserva}" target="_blank" class="btn btn-sm btn-outline-danger rounded-circle">
                                                <i class="bi bi-file-pdf"></i>
                                            </a>
                                        </td>
                                    </tr>
                                </c:forEach>

                                <c:if test="${empty reservas}">
                                    <tr>
                                        <td colspan="5" class="text-center py-5">
                                            <i class="bi bi-inbox text-muted" style="font-size: 3rem;"></i>
                                            <p class="text-muted mt-2">No tienes pedidos en seguimiento actualmente.</p>
                                        </td>
                                    </tr>
                                </c:if>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
