package org.example.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    // Asegúrate de que el nombre de la base de datos sea el correcto
    private static final String URL = "jdbc:mysql://localhost:3306/proyectodonrosel";
    private static final String USER = "root";
    private static final String PASS = "12345678";

    // Este método es el que busca tu UsuarioDAO
    public static Connection getConexion() {
        return conectar();
    }

    // Este método es el que buscan tus 11 errores en ProductoDAO
    public static Connection getConnection() {
        return conectar();
    }

    private static Connection conectar() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USER, PASS);
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("Error de conexión: " + e.getMessage());
            throw new RuntimeException("Error de conexión a la base de datos");
        }
    }
}