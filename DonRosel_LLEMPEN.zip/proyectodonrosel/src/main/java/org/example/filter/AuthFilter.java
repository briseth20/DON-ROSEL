package org.example.filter;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.example.model.Usuario; //
import java.io.IOException;

// Este filtro protege todas las rutas de administración y servlets sensibles
@WebFilter(filterName = "AuthFilter", urlPatterns = {"/panelAdmin", "/AdminServlet", "/admin/*", "/ExportarExcelServlet", "/GenerarPDFServlet", "/generarPDF", "/GenerarReservaPDFServlet", "/generarReservaPDF"})
public class AuthFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Inicialización si es necesaria
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        HttpSession session = httpRequest.getSession(false);

        // 1. Obtener usuario o admin de la sesión
        Usuario usuario = (session != null) ? (Usuario) session.getAttribute("usuario") : null;
        Usuario admin = (session != null) ? (Usuario) session.getAttribute("adminSession") : null;

        String path = httpRequest.getRequestURI();

        // 2. Lógica de Protección
        if (usuario == null && admin == null) {
            // Si no hay sesión, redireccionar al login
            httpResponse.sendRedirect(httpRequest.getContextPath() + "/login.jsp?error=nosession");
        } else {
            // 3. Verificación de Rol (Bug de Admin)
            // Si intenta acceder a rutas de Admin pero su rol es 'cliente'
            if (path.contains("panelAdmin") || path.contains("Admin") || path.contains("Exportar")) {
                if (admin == null || !"admin".equalsIgnoreCase(admin.getRol())) {
                    // Si es cliente, lo mandamos a su perfil o index
                    httpResponse.sendRedirect(httpRequest.getContextPath() + "/index.jsp?error=unauthorized");
                    return;
                }
            }

            // Si todo está bien, continuar
            chain.doFilter(request, response);
        }
    }

    @Override
    public void destroy() {
        // Limpieza
    }
}
