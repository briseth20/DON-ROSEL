package org.example.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.example.dao.ProductoDAO;
import org.example.model.Producto;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "ProductoServlet", urlPatterns = {"/home", ""})
public class ProductoServlet extends HttpServlet {

    private ProductoDAO productoDAO = new ProductoDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // CAPTURAMOS LA ACCIÓN (si viene de "Ver opciones" será "detalle")
        String accion = request.getParameter("accion");

        if ("detalle".equals(accion)) {
            // CASO A: MOSTRAR DETALLE DE UN PRODUCTO
            try {
                int id = Integer.parseInt(request.getParameter("id"));
                Producto p = productoDAO.buscarPorId(id);
                request.setAttribute("p", p);
                request.getRequestDispatcher("detalle_producto.jsp").forward(request, response);
            } catch (Exception e) {
                response.sendRedirect("home"); // Si hay error, volvemos al inicio
            }
        } else {
            // CASO B: MOSTRAR TODO EL CATÁLOGO (Por defecto)
            List<Producto> listaProductos = productoDAO.listarVisibles();
            request.setAttribute("productos", listaProductos);
            request.getRequestDispatcher("index.jsp").forward(request, response);
        }
    }
}