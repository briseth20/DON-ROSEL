package org.example.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import org.example.dao.UsuarioDAO;
import org.example.model.Usuario;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    private final UsuarioDAO dao = new UsuarioDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String accion = request.getParameter("accion");

        // Cerrar sesión
        if ("salir".equals(accion)) {
            HttpSession sesion = request.getSession(false);
            if (sesion != null) {
                sesion.invalidate();
                System.out.println("LOG: Sesión cerrada correctamente.");
            }
            response.sendRedirect("login.jsp");
            return;
        }
        request.getRequestDispatcher("login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String correo = request.getParameter("txtemail");
        String pass = request.getParameter("txtpass");

        // Validación contra la base de datos
        Usuario user = dao.login(correo, pass);

        if (user != null && user.getRol() != null) {
            HttpSession sesion = request.getSession(true);

            // 1. Limpiamos cualquier rastro de sesiones anteriores para evitar el "bug"
            sesion.removeAttribute("usuario");
            sesion.removeAttribute("adminSession");

            // 2. Verificamos el rol ignorando mayúsculas/minúsculas
            if (user.getRol().equalsIgnoreCase("ADMIN")) {
                // Caja exclusiva para Administradores
                sesion.setAttribute("adminSession", user);
                // Mantenemos este por si tus JSPs viejos lo usan
                sesion.setAttribute("adminLogueado", user);


                System.out.println("LOG: Admin logueado: " + user.getNombre());
                // siempre pasar por aqui primero
                response.sendRedirect("panelAdmin");
            } else {
                // Caja exclusiva para Clientes
                sesion.setAttribute("usuario", user);

                System.out.println("LOG: Cliente logueado: " + user.getNombre());
                response.sendRedirect("index.jsp");
            }
        } else {
            // Login fallido
            System.err.println("LOG: Intento de login fallido para: " + correo);
            response.sendRedirect("login.jsp?error=1");
        }
    }
}
