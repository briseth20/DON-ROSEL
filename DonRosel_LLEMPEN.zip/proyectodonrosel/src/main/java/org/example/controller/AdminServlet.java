package org.example.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import org.example.dao.*;
import org.example.model.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/panelAdmin")
public class AdminServlet extends HttpServlet {

    private final ProductoDAO productoDao = new ProductoDAO();
    private final ReservaDAO reservaDao = new ReservaDAO();
    private final VentaDAO ventaDao = new VentaDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        // 1. Verificamos sesión (Asegúrate que en el Login guardes como "adminSession")
        if (session == null || session.getAttribute("adminSession") == null) {
            System.out.println("DEBUG: No hay sesión de admin, redirigiendo...");
            response.sendRedirect("login.jsp?error=no_session");
            return;
        }

        Usuario admin = (Usuario) session.getAttribute("adminSession");
        String accion = request.getParameter("accion");

        if ("cambiarEstado".equals(accion)) {
            try {
                int id = Integer.parseInt(request.getParameter("id"));
                boolean estado = Boolean.parseBoolean(request.getParameter("estado"));
                productoDao.cambiarVisibilidad(id, estado);
            } catch (Exception e) {
                System.err.println("ERROR en cambiarEstado: " + e.getMessage());
            }
            response.sendRedirect("panelAdmin");
            return;
        }

        // 2. Cargamos los datos
        try {
            List<Producto> lp = productoDao.listarTodoParaAdmin();
            List<Venta> lv = ventaDao.listarTodasLasVentas();
            List<Reserva> lr = reservaDao.listarTodasLasReservas();
            DashboardResumen dashboard = ventaDao.obtenerDashboardResumen();

            // === ESTO ES LO MÁS IMPORTANTE PARA TI AHORA ===
            // Revisa la consola de tu IDE (abajo) al cargar la página
            System.out.println("--- DIAGNÓSTICO DE DATOS ---");
            System.out.println("Productos encontrados: " + (lp != null ? lp.size() : "NULL"));
            System.out.println("Ventas encontradas: " + (lv != null ? lv.size() : "NULL"));
            System.out.println("Reservas encontradas: " + (lr != null ? lr.size() : "NULL"));

            request.setAttribute("usuario", admin);
            request.setAttribute("productosTotal", lp);
            request.setAttribute("historialVentas", lv);
            request.setAttribute("listaReservas", lr);
            request.setAttribute("dashboard", dashboard);

            request.getRequestDispatcher("admin_panel.jsp").forward(request, response);

        } catch (Exception e) {
            System.err.println("ERROR CRÍTICO EN ADMINSERVLET: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("adminSession") == null) {
            response.sendRedirect("login.jsp?error=no_session");
            return;
        }

        String accion = request.getParameter("accion");
        try {
            if ("actualizarStock".equals(accion)) {
                int id = Integer.parseInt(request.getParameter("id"));
                int nuevoStock = Integer.parseInt(request.getParameter("nuevoStock"));
                productoDao.actualizarStock(id, nuevoStock);
            } else if ("actualizarEstadoPedido".equals(accion)) {
                int idVenta = Integer.parseInt(request.getParameter("idVenta"));
                String nuevoEstado = request.getParameter("nuevoEstado");
                ventaDao.actualizarEstado(idVenta, nuevoEstado);
            } else if ("actualizarEstadoReserva".equals(accion)) {
                int idReserva = Integer.parseInt(request.getParameter("idReserva"));
                String nuevoEstado = request.getParameter("nuevoEstado");
                reservaDao.actualizarEstadoReserva(idReserva, nuevoEstado);
            } else if ("cancelarVenta".equals(accion)) {
                int idVenta = Integer.parseInt(request.getParameter("idVenta"));
                ventaDao.actualizarEstado(idVenta, "cancelado");
            } else if ("cancelarReserva".equals(accion)) {
                int idReserva = Integer.parseInt(request.getParameter("idReserva"));
                reservaDao.actualizarEstadoReserva(idReserva, "CANCELADO");
            } else if ("registrarVentaExterna".equals(accion)) {
                int idProducto = Integer.parseInt(request.getParameter("idProducto"));
                int cantidad = Integer.parseInt(request.getParameter("cantidad"));
                String metodo = request.getParameter("metodoPago");
                String nombre = request.getParameter("nombreTitular");
                String telefono = request.getParameter("telefono");
                String direccion = request.getParameter("direccion");

                Producto p = productoDao.buscarPorId(idProducto);
                if (p != null && cantidad > 0) {
                    Venta v = new Venta();
                    v.setIdUsuario(null);
                    v.setMontoTotal(p.getPrecio() * cantidad);
                    v.setMetodoPago(metodo);
                    v.setEstado("pagado");
                    v.setNombreTitular(nombre);
                    v.setTelefono(telefono);
                    v.setDireccionEnvio(direccion);
                    v.setEsVentaExterna(true);

                    Carrito item = new Carrito();
                    item.setIdProducto(p.getId());
                    item.setNombre(p.getNombre());
                    item.setCantidad(cantidad);
                    item.setPrecioUnitario(p.getPrecio());

                    List<Carrito> detalle = new ArrayList<>();
                    detalle.add(item);
                    ventaDao.registrarVenta(v, detalle);
                }
            }
        } catch (Exception e) {
            System.err.println("ERROR en doPost AdminServlet: " + e.getMessage());
        }

        response.sendRedirect("panelAdmin");
    }
}
