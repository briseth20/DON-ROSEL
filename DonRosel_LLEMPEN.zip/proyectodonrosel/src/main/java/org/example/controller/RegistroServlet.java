package org.example.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import org.example.dao.UsuarioDAO;
import org.example.model.Usuario;
import java.io.IOException;

@WebServlet("/registro")
public class RegistroServlet extends HttpServlet {

    private final UsuarioDAO dao = new UsuarioDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Simplemente muestra el formulario de registro
        request.getRequestDispatcher("registro.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 1. Capturamos los datos (Asegúrate que en registro.jsp digan estos nombres)
        String nombre = request.getParameter("txtnombre");
        String correo = request.getParameter("txtemail");
        String pass = request.getParameter("txtpass");

        // --- VALIDACIÓN DE CORREO EXISTENTE ---
        if (dao.existeCorreo(correo)) {
            request.setAttribute("error", "El correo ya está registrado.");
            // Usamos forward para que el mensaje de error llegue al JSP
            request.getRequestDispatcher("registro.jsp").forward(request, response);
            return; // Detenemos la ejecución aquí
        }
        //

        // 2. Creamos el objeto Usuario
        Usuario u = new Usuario();
        u.setNombre(nombre);
        u.setCorreo(correo);
        u.setPassword(pass);
        u.setRol("USER"); // Por defecto siempre es cliente

        // 3. Intentamos registrar en la BD
        boolean resultado = dao.registrar(u);

        if (resultado) {
            System.out.println("LOG: Usuario registrado con éxito: " + correo);
            // Redirigimos al login con un mensaje de éxito
            response.sendRedirect("login.jsp?registro=success");
        } else {
            System.err.println("LOG: Fallo al registrar usuario en la BD.");
            // Redirigimos de vuelta al registro con mensaje de error
            response.sendRedirect("registro.jsp?error=1");
        }
    }
}