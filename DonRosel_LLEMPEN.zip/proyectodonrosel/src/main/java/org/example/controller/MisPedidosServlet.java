package org.example.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.example.dao.VentaDAO;
import org.example.model.Usuario;
import org.example.model.Venta;

import java.io.IOException;
import java.util.List;

@WebServlet("/mis-pedidos")
public class MisPedidosServlet extends HttpServlet {
    private final VentaDAO ventaDao = new VentaDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        Usuario user = (session != null) ? (Usuario) session.getAttribute("usuario") : null;

        if (user == null) {
            response.sendRedirect("login.jsp?error=sesion");
            return;
        }

        List<Venta> pedidos = ventaDao.listarVentasPorUsuario(user.getId_usuario());
        request.setAttribute("usuario", user);
        request.setAttribute("misPedidos", pedidos);
        request.getRequestDispatcher("mis_pedidos.jsp").forward(request, response);
    }
}
