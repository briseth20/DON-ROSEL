package org.example.controller;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.UnitValue;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.example.dao.ProductoDAO;
import org.example.dao.VentaDAO;
import org.example.model.Carrito;
import org.example.model.Venta;
import java.io.IOException;
import java.util.List;

@WebServlet({"/generarPDF", "/GenerarPDFServlet"})
public class GenerarPDFServlet extends HttpServlet {
    private final ProductoDAO pdao = new ProductoDAO();
    private final VentaDAO vdao = new VentaDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String idVentaStr = request.getParameter("idVenta");
        if (idVentaStr == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Falta idVenta");
            return;
        }
        int idVenta = Integer.parseInt(idVentaStr);
        List<Carrito> items = pdao.obtenerDetallesVenta(idVenta);
        Venta venta = vdao.obtenerVentaPorId(idVenta);

        // Configurar cabeceras para que el navegador entienda que es un PDF
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=Boleta_DonRosel_" + idVenta + ".pdf");

        try (PdfWriter writer = new PdfWriter(response.getOutputStream());
             PdfDocument pdf = new PdfDocument(writer);
             Document document = new Document(pdf)) {

            document.add(new Paragraph("DON ROSEL - BOLETA DE VENTA").setBold().setFontSize(18));
            document.add(new Paragraph("Venta Nro: " + idVenta));
            if (venta != null) {
                document.add(new Paragraph("Cliente: " + (venta.getNombreTitular() != null ? venta.getNombreTitular() : "Invitado")));
                document.add(new Paragraph("Fecha: " + venta.getFecha()));
                document.add(new Paragraph("Metodo de pago: " + venta.getMetodoPago()));
                document.add(new Paragraph("Estado: " + venta.getEstado()));
                if (venta.getTelefono() != null && !venta.getTelefono().isBlank()) {
                    document.add(new Paragraph("Telefono: " + venta.getTelefono()));
                }
                if (venta.getDireccionEnvio() != null && !venta.getDireccionEnvio().isBlank()) {
                    document.add(new Paragraph("Direccion de envio: " + venta.getDireccionEnvio()));
                }
            }
            document.add(new Paragraph("--------------------------------------------------"));

            // Crear Tabla de productos
            float[] columnWidths = {1, 5, 2, 2};
            Table table = new Table(UnitValue.createPercentArray(columnWidths));
            table.addHeaderCell("Cant.");
            table.addHeaderCell("Producto");
            table.addHeaderCell("P. Unit");
            table.addHeaderCell("Subtotal");

            double total = 0;
            for (Carrito item : items) {
                double subtotal = item.getCantidad() * item.getPrecioUnitario();
                total += subtotal;
                table.addCell(String.valueOf(item.getCantidad()));
                table.addCell(item.getNombre());
                table.addCell("S/ " + item.getPrecioUnitario());
                table.addCell("S/ " + subtotal);
            }
            document.add(table);
            document.add(new Paragraph("\nTOTAL A PAGAR: S/ " + total).setBold());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
