package org.example.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.example.model.Carrito;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "CarritoServlet", urlPatterns = {"/carrito"})
public class CarritoServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accion = request.getParameter("accion");
        HttpSession session = request.getSession();
        List<Carrito> carrito = (List<Carrito>) session.getAttribute("carrito");
        if (carrito == null) carrito = new ArrayList<>();

        // --- LÓGICA PARA RESERVAS ---
        if ("AgregarCarrito".equals(accion)) {
            try {
                int idp = Integer.parseInt(request.getParameter("id"));
                String idReserva = request.getParameter("idReserva");

                Carrito car = new Carrito();
                car.setIdProducto(idp);
                car.setNombre("Reserva Especial Geisha");
                car.setCantidad(1);
                car.setPrecioUnitario(150.00);
                car.setPeso("250g");

                carrito.removeIf(item -> item.getIdProducto() == idp);
                carrito.add(car);
                actualizarSesion(session, carrito);

                response.sendRedirect("carrito.jsp?idReserva=" + idReserva);
                return;
            } catch (Exception e) {
                response.sendRedirect("index.jsp?error=reserva");
                return;
            }
        }

        // --- LÓGICA EXISTENTE ---
        if ("eliminar".equals(accion) && carrito != null) {
            int idEliminar = Integer.parseInt(request.getParameter("id"));
            carrito.removeIf(item -> item.getIdProducto() == idEliminar);
            actualizarSesion(session, carrito);
        }

        if ("vaciar".equals(accion)) {
            session.removeAttribute("carrito");
            session.removeAttribute("total");
        }

        response.sendRedirect("carrito.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        List<Carrito> carrito = (List<Carrito>) session.getAttribute("carrito");
        if (carrito == null) {
            carrito = new ArrayList<>();
        }

        // Captura del método de pago (si el formulario de pago apunta aquí)
        String metodoPago = request.getParameter("metodoPago");
        if (metodoPago != null) {
            session.setAttribute("metodoPago", metodoPago);
        }

        // Captura de datos del formulario de detalle de producto
        String idStr = request.getParameter("id");

        // Verificamos si es una acción de agregar producto normal
        if (idStr != null) {
            int idp = Integer.parseInt(idStr);
            String nombre = request.getParameter("nombreProducto");
            String peso = request.getParameter("pesoElegido") + "g";
            double precioTotalRecibido = Double.parseDouble(request.getParameter("precioOculto"));
            int cantidad = Integer.parseInt(request.getParameter("cantidadElegida"));

            double precioUnitario = precioTotalRecibido / cantidad;

            boolean existe = false;
            for (Carrito c : carrito) {
                if (c.getIdProducto() == idp && c.getPeso().equals(peso)) {
                    c.setCantidad(c.getCantidad() + cantidad);
                    existe = true;
                    break;
                }
            }

            if (!existe) {
                Carrito car = new Carrito();
                car.setIdProducto(idp);
                car.setNombre(nombre);
                car.setPeso(peso);
                car.setPrecioUnitario(precioUnitario);
                car.setCantidad(cantidad);
                carrito.add(car);
            }
        }

        actualizarSesion(session, carrito);
        response.sendRedirect("carrito.jsp");
    }

    private void actualizarSesion(HttpSession session, List<Carrito> carrito) {
        if (carrito == null || carrito.isEmpty()) {
            session.removeAttribute("total");
            session.removeAttribute("carrito");
        } else {
            double total = carrito.stream()
                    .mapToDouble(item -> item.getPrecioUnitario() * item.getCantidad())
                    .sum();
            session.setAttribute("carrito", carrito);
            session.setAttribute("total", total);
        }
    }
}