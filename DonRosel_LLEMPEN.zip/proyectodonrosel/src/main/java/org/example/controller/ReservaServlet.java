package org.example.controller;

import org.example.dao.ReservaDAO;
import org.example.model.Reserva;
import org.example.model.Producto;
import org.example.model.Usuario;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/ReservaServlet")
public class ReservaServlet extends HttpServlet {
    private final ReservaDAO reservaDAO = new ReservaDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Soporte para ambos nombres de parámetro (action/accion)
        String action = request.getParameter("action");
        if (action == null) action = request.getParameter("accion");

        if (action == null) {
            response.sendRedirect("index.jsp");
            return;
        }

        switch (action) {
            case "solicitar":
                registrarSolicitud(request, response);
                break;
            case "mis-reservas":
                listarReservasCliente(request, response);
                break;
            case "confirmar":
                // Cambia el estado a PREPARANDO para activar el botón de pago
                actualizarEstadoDirecto(request, response, "PREPARANDO");
                break;
            case "actualizarEstadoAdmin":
                actualizarEstadoTracking(request, response);
                break;
            default:
                response.sendRedirect("index.jsp");
                break;
        }
    }

    private void registrarSolicitud(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession(false);
        Usuario user = (session != null) ? (Usuario) session.getAttribute("usuario") : null;

        if (user == null) {
            response.sendRedirect("login.jsp?error=sesion");
            return;
        }

        try {
            String idProdStr = request.getParameter("idProducto");
            if (idProdStr != null) {
                int idProducto = Integer.parseInt(idProdStr.trim());
                Reserva nuevaReserva = new Reserva();
                nuevaReserva.setUsuario(user);

                Producto p = new Producto();
                p.setId(idProducto);
                nuevaReserva.setProducto(p);

                // IMPORTANTE: Aquí se ejecuta la inserción en la BD
                if (reservaDAO.solicitarReserva(nuevaReserva)) {
                    response.sendRedirect("ReservaServlet?action=mis-reservas");
                } else {
                    response.sendRedirect("index.jsp?error=db_insert");
                }
            } else {
                response.sendRedirect("index.jsp?error=no_id");
            }
        } catch (NumberFormatException e) {
            response.sendRedirect("index.jsp?error=id_invalido");
        }
    }

    private void listarReservasCliente(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        Usuario user = (session != null) ? (Usuario) session.getAttribute("usuario") : null;

        if (user == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        // Recupera de la BD solo las del usuario actual
        List<Reserva> lista = reservaDAO.listarPorUsuario(user.getId_usuario());
        request.setAttribute("reservas", lista);
        request.getRequestDispatcher("mis_reservas.jsp").forward(request, response);
    }

    private void actualizarEstadoDirecto(HttpServletRequest request, HttpServletResponse response, String estado) throws IOException {
        String idRes = request.getParameter("idReserva");
        try {
            if (idRes != null) {
                int id = Integer.parseInt(idRes.trim());
                // IMPORTANTE: Aquí se ejecuta el UPDATE en la BD
                if (reservaDAO.actualizarEstadoReserva(id, estado)) {
                    response.sendRedirect("panelAdmin?success=reservaConfirmada");
                } else {
                    response.sendRedirect("panelAdmin?error=db_update");
                }
            } else {
                response.sendRedirect("panelAdmin?error=missing_id");
            }
        } catch (NumberFormatException e) {
            response.sendRedirect("panelAdmin?error=params");
        }
    }

    private void actualizarEstadoTracking(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String idResStr = request.getParameter("idReserva");
        String nuevoEstado = request.getParameter("nuevoEstado");

        try {
            if (idResStr != null && nuevoEstado != null) {
                int idReserva = Integer.parseInt(idResStr.trim());
                String estadoFormateado = nuevoEstado.trim().toUpperCase();

                // IMPORTANTE: Aquí se ejecuta el UPDATE en la BD
                if (reservaDAO.actualizarEstadoReserva(idReserva, estadoFormateado)) {
                    response.sendRedirect("panelAdmin?success=estadoActualizado");
                } else {
                    response.sendRedirect("panelAdmin?error=errorEstado");
                }
            } else {
                response.sendRedirect("panelAdmin?error=faltanParametros");
            }
        } catch (NumberFormatException e) {
            response.sendRedirect("panelAdmin?error=invalidParams");
        }
    }
}