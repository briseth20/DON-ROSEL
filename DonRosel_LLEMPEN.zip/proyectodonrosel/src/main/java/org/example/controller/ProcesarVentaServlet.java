package org.example.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

// ESTOS IMPORTS SON LOS QUE TE FALTAN (Solucionan el error :9 y :20)
import org.example.dao.ReservaDAO;
import org.example.dao.VentaDAO;
import org.example.model.Carrito;
import org.example.model.Usuario;
import org.example.model.Venta;

import java.io.IOException;
import java.util.List;

@WebServlet("/ProcesarVentaServlet")
public class ProcesarVentaServlet extends HttpServlet {

    // Se crea la instancia del DAO
    private final VentaDAO vdao = new VentaDAO();
    private final ReservaDAO reservaDao = new ReservaDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        List<Carrito> listaCarrito = (List<Carrito>) session.getAttribute("carrito");
        Usuario usuarioLogueado = (Usuario) session.getAttribute("usuario");

        if (listaCarrito == null || listaCarrito.isEmpty()) {
            response.sendRedirect("carrito.jsp?error=vacio");
            return;
        }

        String metodoPago = request.getParameter("metodo_pago");
        String nroOperacion = request.getParameter("nro_operacion");
        String nombreTitular = request.getParameter("nombre");
        String direccion = request.getParameter("direccion");
        String telefono = request.getParameter("telefono");

        double total = 0;
        for (Carrito c : listaCarrito) {
            // SOLUCIÓN ERROR :48 -> Si getSubtotal() falla, usamos cantidad * precio
            total += (c.getCantidad() * c.getPrecioUnitario());
        }

        Venta v = new Venta();

        if (usuarioLogueado != null) {
            v.setIdUsuario(usuarioLogueado.getId_usuario());
        } else {
            v.setIdUsuario(null);
        }

        v.setMontoTotal(total);
        v.setMetodoPago(metodoPago);
        v.setNroOperacion(nroOperacion);
        v.setNombreTitular(nombreTitular);
        v.setDireccionEnvio(direccion);
        v.setTelefono(telefono);

        // Estado inicial
        v.setEstado("pendiente_pago");

        // SOLUCIÓN ERROR :76 -> Llamada correcta al DAO
        int idVentaGenerada = vdao.registrarVenta(v, listaCarrito);

        if (idVentaGenerada > 0) {
            String idReservaStr = request.getParameter("idReserva");
            if (idReservaStr != null && !idReservaStr.isBlank()) {
                try {
                    int idReserva = Integer.parseInt(idReservaStr.trim());
                    // Marca la reserva como pagada; el admin define el siguiente estado.
                    reservaDao.actualizarEstadoReserva(idReserva, "PAGADO");
                } catch (NumberFormatException e) {
                    System.err.println("WARN: idReserva invalido: " + idReservaStr);
                }
            }
            session.removeAttribute("carrito");
            response.sendRedirect("gracias.jsp?id=" + idVentaGenerada);
        } else {
            response.sendRedirect("carrito.jsp?error=bd");
        }
    }
}
