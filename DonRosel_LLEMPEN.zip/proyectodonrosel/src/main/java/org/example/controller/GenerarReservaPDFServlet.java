package org.example.controller;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.UnitValue;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.example.dao.ReservaDAO;
import org.example.model.Reserva;

import java.io.IOException;

@WebServlet({"/generarReservaPDF", "/GenerarReservaPDFServlet"})
public class GenerarReservaPDFServlet extends HttpServlet {
    private final ReservaDAO reservaDao = new ReservaDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String idReservaStr = request.getParameter("idReserva");
        if (idReservaStr == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Falta idReserva");
            return;
        }

        int idReserva = Integer.parseInt(idReservaStr);
        Reserva reserva = reservaDao.obtenerPorId(idReserva);
        if (reserva == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Reserva no encontrada");
            return;
        }

        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=Boleta_Reserva_DonRosel_" + idReserva + ".pdf");

        try (PdfWriter writer = new PdfWriter(response.getOutputStream());
             PdfDocument pdf = new PdfDocument(writer);
             Document document = new Document(pdf)) {

            document.add(new Paragraph("DON ROSEL - BOLETA DE RESERVA").setBold().setFontSize(18));
            document.add(new Paragraph("Reserva Nro: " + idReserva));
            document.add(new Paragraph("Cliente: " + reserva.getUsuario().getNombre()));
            document.add(new Paragraph("Fecha: " + reserva.getFechaSolicitud()));
            document.add(new Paragraph("Estado: " + reserva.getEstado()));
            document.add(new Paragraph("--------------------------------------------------"));

            float[] columnWidths = {1, 5, 2, 2};
            Table table = new Table(UnitValue.createPercentArray(columnWidths));
            table.addHeaderCell("Cant.");
            table.addHeaderCell("Producto");
            table.addHeaderCell("P. Unit");
            table.addHeaderCell("Subtotal");

            double precio = reserva.getProducto().getPrecio();
            table.addCell("1");
            table.addCell(reserva.getProducto().getNombre());
            table.addCell("S/ " + precio);
            table.addCell("S/ " + precio);

            document.add(table);
            document.add(new Paragraph("\nTOTAL A PAGAR: S/ " + precio).setBold());
        }
    }
}
