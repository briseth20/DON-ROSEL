package org.example.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.example.dao.ReservaDAO;
import org.example.dao.VentaDAO;
import org.example.model.Reserva;
import org.example.model.VentaDetalleReporte;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.IOException;
import java.util.List;

@WebServlet("/ExportarExcelServlet")
public class ExportarExcelServlet extends HttpServlet {

    private final VentaDAO vdao = new VentaDAO();
    private final ReservaDAO reservaDao = new ReservaDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<VentaDetalleReporte> ventas = vdao.listarDetallesVentasReporte();
        List<Reserva> reservas = reservaDao.listarTodasLasReservas();

        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setHeader("Content-Disposition", "attachment; filename=Reporte_Ventas_DonRosel.xlsx");

        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheetVentas = workbook.createSheet("Ventas");
            Sheet sheetReservas = workbook.createSheet("Reservas");

            // Estilo de encabezado
            CellStyle headerStyle = workbook.createCellStyle();
            Font font = workbook.createFont();
            font.setBold(true);
            font.setColor(IndexedColors.WHITE.getIndex());
            headerStyle.setFont(font);
            headerStyle.setFillForegroundColor(IndexedColors.DARK_GREEN.getIndex());
            headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            // Estilo para Montos (Moneda S/)
            CellStyle currencyStyle = workbook.createCellStyle();
            DataFormat df = workbook.createDataFormat();
            currencyStyle.setDataFormat(df.getFormat("S/ #,##0.00"));

            // 1. Encabezados Ventas
            Row headerRowVentas = sheetVentas.createRow(0);
            String[] columnasVentas = {"ID Venta", "Fecha", "Cliente", "Metodo", "Estado", "Tipo", "Producto", "Cantidad", "Precio Unit.", "Subtotal", "Total Venta"};

            for (int i = 0; i < columnasVentas.length; i++) {
                Cell cell = headerRowVentas.createCell(i);
                cell.setCellValue(columnasVentas[i]);
                cell.setCellStyle(headerStyle);
            }

            // 2. Datos Ventas
            int rowIdx = 1;
            for (VentaDetalleReporte v : ventas) {
                Row row = sheetVentas.createRow(rowIdx++);
                row.createCell(0).setCellValue(v.getIdVenta());
                row.createCell(1).setCellValue(v.getFecha());
                row.createCell(2).setCellValue(v.getCliente());
                row.createCell(3).setCellValue(v.getMetodoPago());
                row.createCell(4).setCellValue(v.getEstado());
                row.createCell(5).setCellValue(v.getTipoVenta());
                row.createCell(6).setCellValue(v.getProducto());
                row.createCell(7).setCellValue(v.getCantidad());

                Cell cellPrecio = row.createCell(8);
                cellPrecio.setCellValue(v.getPrecioUnitario());
                cellPrecio.setCellStyle(currencyStyle);

                Cell cellSubtotal = row.createCell(9);
                cellSubtotal.setCellValue(v.getSubtotal());
                cellSubtotal.setCellStyle(currencyStyle);

                Cell cellTotal = row.createCell(10);
                cellTotal.setCellValue(v.getMontoTotal());
                cellTotal.setCellStyle(currencyStyle);
            }

            for (int i = 0; i < columnasVentas.length; i++) {
                sheetVentas.autoSizeColumn(i);
            }

            // 3. Encabezados Reservas
            Row headerRowReservas = sheetReservas.createRow(0);
            String[] columnasReservas = {"ID Reserva", "Fecha", "Cliente", "Producto", "Estado", "Precio"};

            for (int i = 0; i < columnasReservas.length; i++) {
                Cell cell = headerRowReservas.createCell(i);
                cell.setCellValue(columnasReservas[i]);
                cell.setCellStyle(headerStyle);
            }

            // 4. Datos Reservas
            int rowResIdx = 1;
            for (Reserva r : reservas) {
                Row row = sheetReservas.createRow(rowResIdx++);
                row.createCell(0).setCellValue(r.getIdReserva());
                row.createCell(1).setCellValue(String.valueOf(r.getFechaSolicitud()));
                row.createCell(2).setCellValue(r.getUsuario().getNombre());
                row.createCell(3).setCellValue(r.getProducto().getNombre());
                row.createCell(4).setCellValue(r.getEstado());

                Cell cellPrecio = row.createCell(5);
                cellPrecio.setCellValue(r.getProducto().getPrecio());
                cellPrecio.setCellStyle(currencyStyle);
            }

            for (int i = 0; i < columnasReservas.length; i++) {
                sheetReservas.autoSizeColumn(i);
            }

            workbook.write(response.getOutputStream());
            System.out.println("LOG: Excel generado con éxito.");

        } catch (Exception e) {
            System.err.println("Error al exportar Excel: " + e.getMessage());
        }
    }
}
