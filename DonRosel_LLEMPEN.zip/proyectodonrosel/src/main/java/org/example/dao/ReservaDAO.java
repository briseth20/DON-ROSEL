package org.example.dao;

import org.example.config.Conexion;
import org.example.model.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ReservaDAO {
    private final Conexion cn = new Conexion();

    /**
     * Obtiene todas las reservas para el panel de administración.
     * Nombre: listarTodasLasReservas (Sincronizado con AdminServlet)
     */
    public List<Reserva> listarTodasLasReservas() {
        List<Reserva> lista = new ArrayList<>();
        // Usamos LEFT JOIN para evitar que la reserva desaparezca si el producto o usuario no cruzan bien
        String sql = "SELECT r.*, p.nombre as prod_nombre, p.precio, u.nombre as user_nombre " +
                "FROM reservas r " +
                "LEFT JOIN productos p ON r.id_producto = p.id_producto " +
                "LEFT JOIN usuarios u ON r.id_usuario = u.id_usuario " +
                "ORDER BY r.fecha_solicitud DESC";

        try (Connection con = cn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapReserva(rs, true));
            }
        } catch (SQLException e) {
            System.err.println("Error en ReservaDAO.listarTodasLasReservas: " + e.getMessage());
            e.printStackTrace();
        }
        return lista;
    }

    /**
     * Obtiene las reservas de un cliente específico para su perfil.
     */
    public List<Reserva> listarPorUsuario(int idUsuario) {
        List<Reserva> lista = new ArrayList<>();
        String sql = "SELECT r.*, p.nombre as prod_nombre, p.precio " +
                "FROM reservas r " +
                "LEFT JOIN productos p ON r.id_producto = p.id_producto " +
                "WHERE r.id_usuario = ? ORDER BY r.fecha_solicitud DESC";

        try (Connection con = cn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idUsuario);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapReserva(rs, false));
                }
            }
        } catch (SQLException e) {
            System.err.println("ERROR en listarPorUsuario: " + e.getMessage());
        }
        return lista;
    }

    /**
     * Busca una reserva por su ID.
     */
    public Reserva obtenerPorId(int id) {
        String sql = "SELECT r.*, p.nombre as prod_nombre, p.precio, u.nombre as user_nombre " +
                "FROM reservas r " +
                "LEFT JOIN productos p ON r.id_producto = p.id_producto " +
                "LEFT JOIN usuarios u ON r.id_usuario = u.id_usuario WHERE r.id_reserva = ?";

        try (Connection con = cn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapReserva(rs, true);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Actualiza el estado de la reserva (ENUM en DB: PENDIENTE, PREPARANDO, LISTO_PARA_PAGO, COMPLETADO)
     */
    public boolean actualizarEstadoReserva(int id, String estado) {
        String sql = "UPDATE reservas SET estado = ? WHERE id_reserva = ?";
        try (Connection con = cn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, estado.trim().toUpperCase());
            ps.setInt(2, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("ERROR en actualizarEstadoReserva: " + e.getMessage());
            return false;
        }
    }

    /**
     * Inserta una nueva reserva desde el lado del cliente.
     */
    public boolean solicitarReserva(Reserva res) {
        String sql = "INSERT INTO reservas (id_usuario, id_producto, estado, fecha_solicitud) VALUES (?, ?, 'PENDIENTE', NOW())";
        try (Connection con = cn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            if (res.getUsuario() != null && res.getProducto() != null) {
                ps.setInt(1, res.getUsuario().getId_usuario());
                ps.setInt(2, res.getProducto().getId()); // Sincronizado con Producto (id)
                return ps.executeUpdate() > 0;
            }
            return false;
        } catch (SQLException e) {
            System.err.println("ERROR en solicitarReserva: " + e.getMessage());
            return false;
        }
    }

    /**
     * Método de utilidad para convertir ResultSet a objeto Reserva.
     * Evita NullPointerException si el JOIN no encuentra nombres.
     */
    private Reserva mapReserva(ResultSet rs, boolean incluirUsuario) throws SQLException {
        Reserva res = new Reserva();
        res.setIdReserva(rs.getInt("id_reserva"));
        res.setEstado(rs.getString("estado"));
        res.setFechaSolicitud(rs.getTimestamp("fecha_solicitud"));

        // Mapeo de Producto
        Producto p = new Producto();
        p.setId(rs.getInt("id_producto"));
        String nombreP = rs.getString("prod_nombre");
        p.setNombre(nombreP != null ? nombreP : "Producto no disponible");
        try {
            p.setPrecio(rs.getDouble("precio"));
        } catch (Exception e) {
            p.setPrecio(0.0);
        }
        res.setProducto(p);

        // Mapeo de Usuario (solo si se requiere, ej: para el Admin)
        if (incluirUsuario) {
            Usuario u = new Usuario();
            u.setId_usuario(rs.getInt("id_usuario"));
            String nombreU = rs.getString("user_nombre");
            u.setNombre(nombreU != null ? nombreU : "Cliente no encontrado");
            res.setUsuario(u);
        }
        return res;
    }

    // Alias para compatibilidad si usaste otros nombres en el Servlet
    public boolean confirmarReserva(int id) {
        return actualizarEstadoReserva(id, "PREPARANDO");
    }

    public Reserva buscarPorId(int id) {
        return obtenerPorId(id);
    }
}