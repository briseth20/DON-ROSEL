package org.example.dao;

import org.example.config.Conexion;
import org.example.model.Producto;
import org.example.model.Venta;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import org.example.model.Carrito;

public class ProductoDAO {
    private final Conexion cn = new Conexion();
    private Connection con;
    private PreparedStatement ps;
    private ResultSet rs;

    // --- MÉTODOS DE PRODUCTOS ---

    public List<Producto> listarVisibles() {
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT * FROM productos WHERE es_visible = 1";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Producto p = new Producto();
                p.setId(rs.getInt("id_producto"));
                p.setNombre(rs.getString("nombre"));
                p.setDescripcion(rs.getString("descripcion"));
                p.setPrecio(rs.getDouble("precio"));
                p.setStock(rs.getInt("stock"));
                p.setIdCategoria(rs.getInt("id_categoria"));
                p.setTostado(rs.getString("tostado"));
                p.setPeso(rs.getString("peso"));
                p.setImagen(rs.getString("imagen_url"));
                p.setTipo(rs.getString("tipo"));
                lista.add(p);
            }
        } catch (Exception e) {
            System.err.println("Error al listar visibles: " + e);
        } finally { cerrarConexiones(); }
        return lista;
    }

    public List<Producto> listarTodoParaAdmin() {
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT * FROM productos";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Producto p = new Producto();
                p.setId(rs.getInt("id_producto"));
                p.setNombre(rs.getString("nombre"));
                p.setPrecio(rs.getDouble("precio"));
                p.setStock(rs.getInt("stock"));
                p.setEsVisible(rs.getBoolean("es_visible"));
                p.setTostado(rs.getString("tostado"));
                p.setPeso(rs.getString("peso"));
                p.setTipo(rs.getString("tipo"));
                lista.add(p);
            }
        } catch (Exception e) {
            System.err.println("Error listarAdmin: " + e);
        } finally { cerrarConexiones(); }
        return lista;
    }

    public Producto buscarPorId(int id) {
        Producto p = new Producto();
        String sql = "SELECT * FROM productos WHERE id_producto = ?";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            if (rs.next()) {
                p.setId(rs.getInt("id_producto"));
                p.setNombre(rs.getString("nombre"));
                p.setDescripcion(rs.getString("descripcion"));
                p.setPrecio(rs.getDouble("precio"));
                p.setImagen(rs.getString("imagen_url"));
                p.setStock(rs.getInt("stock"));
                p.setIdCategoria(rs.getInt("id_categoria"));
                p.setTostado(rs.getString("tostado"));
                p.setPeso(rs.getString("peso"));
                p.setTipo(rs.getString("tipo"));
            }
        } catch (Exception e) {
            System.err.println("Error en buscarPorId: " + e);
        } finally { cerrarConexiones(); }
        return p;
    }

    // --- MÉTODOS DE ACTUALIZACIÓN ---

    public void cambiarVisibilidad(int id, boolean estado) {
        String sql = "UPDATE productos SET es_visible=? WHERE id_producto=?";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setBoolean(1, estado);
            ps.setInt(2, id);
            ps.executeUpdate();
        } catch (Exception e) {
            System.err.println("Error visibilidad: " + e);
        } finally { cerrarConexiones(); }
    }

    public void actualizarStock(int id, int stock) {
        String sql = "UPDATE productos SET stock=? WHERE id_producto=?";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, stock);
            ps.setInt(2, id);
            ps.executeUpdate();
        } catch (Exception e) {
            System.err.println("Error al actualizar stock: " + e);
        } finally { cerrarConexiones(); }
    }

    // --- MÉTODOS DE VENTAS (CORREGIDOS) ---

    public List<Carrito> obtenerDetallesVenta(int idVenta) {
        List<Carrito> detalles = new ArrayList<>();
        String sql = "SELECT dv.*, p.nombre FROM detalle_ventas dv " +
                "JOIN productos p ON dv.id_producto = p.id_producto WHERE dv.id_venta = ?";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, idVenta);
            rs = ps.executeQuery();
            while (rs.next()) {
                Carrito item = new Carrito();
                item.setIdProducto(rs.getInt("id_producto"));
                item.setNombre(rs.getString("nombre"));
                item.setCantidad(rs.getInt("cantidad"));
                // CORRECCIÓN: nombre de columna 'precio_unitario'
                item.setPrecioUnitario(rs.getDouble("precio_unitario"));
                detalles.add(item);
            }
        } catch (Exception e) {
            System.err.println("Error en obtenerDetallesVenta: " + e);
        } finally { cerrarConexiones(); }
        return detalles;
    }

    public List<Venta> listarVentasPorUsuario(int idUsuario) {
        List<Venta> lista = new ArrayList<>();
        // CORRECCIÓN: columna id_usuario
        String sql = "SELECT * FROM ventas WHERE id_usuario = ? ORDER BY fecha DESC";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, idUsuario);
            rs = ps.executeQuery();
            while (rs.next()) {
                Venta v = new Venta(); // CORRECCIÓN: Usar Venta directa
                v.setIdVenta(rs.getInt("id_venta"));
                v.setMontoTotal(rs.getDouble("monto_total"));
                v.setFecha(rs.getString("fecha"));
                v.setEstado(rs.getString("estado"));
                v.setMetodoPago(rs.getString("metodo_pago"));
                lista.add(v);
            }
        } catch (Exception e) {
            System.err.println("Error listarVentasPorUsuario: " + e);
        } finally { cerrarConexiones(); }
        return lista;
    }

    public List<Venta> listarVentas() {
        List<Venta> lista = new ArrayList<>();
        // CORRECCIÓN: nombres de columnas y tablas
        String sql = "SELECT v.*, u.nombre as nombre_cliente FROM ventas v " +
                "LEFT JOIN usuarios u ON v.id_usuario = u.id_usuario ORDER BY v.fecha DESC";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Venta v = new Venta(); // CORRECCIÓN: Usar Venta directa
                v.setIdVenta(rs.getInt("id_venta"));
                v.setMontoTotal(rs.getDouble("monto_total"));
                v.setMetodoPago(rs.getString("metodo_pago"));
                v.setFecha(rs.getString("fecha"));
                v.setEstado(rs.getString("estado"));
                v.setNombreTitular(rs.getString("nombre_cliente")); // Reutilizamos titular para el nombre
                lista.add(v);
            }
        } catch (Exception e) {
            System.err.println("Error listarVentas: " + e);
        } finally { cerrarConexiones(); }
        return lista;
    }

    private void cerrarConexiones() {
        try {
            if (rs != null) rs.close();
            if (ps != null) ps.close();
            if (con != null) con.close();
        } catch (SQLException e) {
            System.err.println("Error al cerrar conexión: " + e);
        }
    }
}
