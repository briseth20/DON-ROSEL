package org.example.dao;

import org.example.config.Conexion;
import org.example.model.DashboardResumen;
import org.example.model.Venta;
import org.example.model.VentaDetalleReporte;
import org.example.model.Carrito;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VentaDAO {
    private final Conexion cn = new Conexion();

    public int registrarVenta(Venta v, List<Carrito> detalle) {
        String sqlVenta = "INSERT INTO ventas (id_usuario, monto_total, metodo_pago, estado, nro_operacion, nombre_titular, direccion_envio, telefono_contacto, es_venta_externa) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        String sqlDetalle = "INSERT INTO detalle_ventas (id_venta, id_producto, cantidad, precio_unitario, subtotal) VALUES (?, ?, ?, ?, ?)";
        String sqlStock = "UPDATE productos SET stock = stock - ? WHERE id_producto = ?";
        String sqlOcultar = "UPDATE productos SET es_visible = CASE WHEN stock <= 0 THEN 0 ELSE es_visible END WHERE id_producto = ?";
        int idGenerado = 0;

        try (Connection con = cn.getConnection()) {
            con.setAutoCommit(false);
            try (PreparedStatement psVenta = con.prepareStatement(sqlVenta, Statement.RETURN_GENERATED_KEYS)) {
                if (v.getIdUsuario() != null && v.getIdUsuario() > 0) {
                    psVenta.setInt(1, v.getIdUsuario());
                } else {
                    psVenta.setNull(1, Types.INTEGER);
                }
                psVenta.setDouble(2, v.getMontoTotal());
                psVenta.setString(3, v.getMetodoPago());
                psVenta.setString(4, v.getEstado());
                psVenta.setString(5, v.getNroOperacion());
                psVenta.setString(6, v.getNombreTitular());
                psVenta.setString(7, v.getDireccionEnvio());
                psVenta.setString(8, v.getTelefono());
                psVenta.setBoolean(9, v.isEsVentaExterna());
                psVenta.executeUpdate();

                try (ResultSet rs = psVenta.getGeneratedKeys()) {
                    if (rs.next()) idGenerado = rs.getInt(1);
                }

                try (PreparedStatement psDetalle = con.prepareStatement(sqlDetalle);
                     PreparedStatement psStock = con.prepareStatement(sqlStock);
                     PreparedStatement psOcultar = con.prepareStatement(sqlOcultar)) {
                    for (Carrito item : detalle) {
                        psDetalle.setInt(1, idGenerado);
                        psDetalle.setInt(2, item.getIdProducto());
                        psDetalle.setInt(3, item.getCantidad());
                        psDetalle.setDouble(4, item.getPrecioUnitario());
                        psDetalle.setDouble(5, item.getCantidad() * item.getPrecioUnitario());
                        psDetalle.addBatch();

                        // Descuenta stock y oculta si llega a 0.
                        psStock.setInt(1, item.getCantidad());
                        psStock.setInt(2, item.getIdProducto());
                        psStock.addBatch();
                        psOcultar.setInt(1, item.getIdProducto());
                        psOcultar.addBatch();
                    }
                    psDetalle.executeBatch();
                    psStock.executeBatch();
                    psOcultar.executeBatch();
                }
                con.commit();
            } catch (SQLException e) {
                con.rollback();
                e.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return idGenerado;
    }

    public boolean actualizarEstado(int idVenta, String nuevoEstado) {
        String sql = "UPDATE ventas SET estado = ? WHERE id_venta = ?";
        try (Connection con = cn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, nuevoEstado);
            ps.setInt(2, idVenta);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    public Venta obtenerVentaPorId(int idVenta) {
        String sql = "SELECT v.*, u.nombre AS nombre_cliente " +
                "FROM ventas v LEFT JOIN usuarios u ON v.id_usuario = u.id_usuario " +
                "WHERE v.id_venta = ?";
        try (Connection con = cn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idVenta);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Venta v = new Venta();
                    v.setIdVenta(rs.getInt("id_venta"));
                    v.setMontoTotal(rs.getDouble("monto_total"));
                    v.setMetodoPago(rs.getString("metodo_pago"));
                    v.setEstado(rs.getString("estado"));
                    v.setFecha(rs.getString("fecha"));
                    String nombreTitular = rs.getString("nombre_titular");
                    String nombreCliente = rs.getString("nombre_cliente");
                    v.setNombreTitular(nombreTitular != null ? nombreTitular : nombreCliente);
                    v.setDireccionEnvio(rs.getString("direccion_envio"));
                    v.setTelefono(rs.getString("telefono_contacto"));
                    return v;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Venta> listarVentasPorUsuario(int idUsuario) {
        List<Venta> lista = new ArrayList<>();
        String sql = "SELECT id_venta, monto_total, metodo_pago, estado, fecha " +
                "FROM ventas WHERE id_usuario = ? ORDER BY fecha DESC";
        try (Connection con = cn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idUsuario);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Venta v = new Venta();
                    v.setIdVenta(rs.getInt("id_venta"));
                    v.setMontoTotal(rs.getDouble("monto_total"));
                    v.setMetodoPago(rs.getString("metodo_pago"));
                    v.setFecha(rs.getString("fecha"));
                    v.setEstado(rs.getString("estado"));
                    lista.add(v);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public List<Venta> listarTodasLasVentas() {
        List<Venta> lista = new ArrayList<>();
        // Se cambió el SELECT * por las columnas necesarias para mayor seguridad
        String sql = "SELECT id_venta, monto_total, metodo_pago, estado, fecha FROM ventas ORDER BY id_venta DESC";
        try (Connection con = cn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Venta v = new Venta();
                v.setIdVenta(rs.getInt("id_venta"));
                v.setMontoTotal(rs.getDouble("monto_total"));
                v.setMetodoPago(rs.getString("metodo_pago"));
                v.setEstado(rs.getString("estado"));
                v.setFecha(rs.getString("fecha"));
                lista.add(v);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public List<VentaDetalleReporte> listarDetallesVentasReporte() {
        List<VentaDetalleReporte> lista = new ArrayList<>();
        String sql = "SELECT v.id_venta, v.fecha, v.monto_total, v.metodo_pago, v.estado, v.es_venta_externa, " +
                "COALESCE(u.nombre, 'Invitado') AS cliente, " +
                "p.nombre AS producto, dv.cantidad, dv.precio_unitario, dv.subtotal " +
                "FROM ventas v " +
                "LEFT JOIN usuarios u ON v.id_usuario = u.id_usuario " +
                "LEFT JOIN detalle_ventas dv ON v.id_venta = dv.id_venta " +
                "LEFT JOIN productos p ON dv.id_producto = p.id_producto " +
                "ORDER BY v.id_venta DESC";
        try (Connection con = cn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                VentaDetalleReporte r = new VentaDetalleReporte();
                r.setIdVenta(rs.getInt("id_venta"));
                r.setFecha(rs.getString("fecha"));
                r.setMontoTotal(rs.getDouble("monto_total"));
                r.setMetodoPago(rs.getString("metodo_pago"));
                r.setEstado(rs.getString("estado"));
                r.setTipoVenta(rs.getBoolean("es_venta_externa") ? "Presencial" : "Web");
                r.setCliente(rs.getString("cliente"));
                r.setProducto(rs.getString("producto"));
                r.setCantidad(rs.getInt("cantidad"));
                r.setPrecioUnitario(rs.getDouble("precio_unitario"));
                r.setSubtotal(rs.getDouble("subtotal"));
                lista.add(r);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public DashboardResumen obtenerDashboardResumen() {
        String sql = "SELECT " +
                "SUM(CASE WHEN es_venta_externa = FALSE THEN monto_total ELSE 0 END) AS ventas_web, " +
                "SUM(CASE WHEN es_venta_externa = TRUE THEN monto_total ELSE 0 END) AS ventas_presenciales, " +
                "SUM(monto_total) AS total_combinado " +
                "FROM ventas WHERE estado <> 'cancelado'";
        try (Connection con = cn.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                DashboardResumen resumen = new DashboardResumen();
                resumen.setVentasWeb(rs.getDouble("ventas_web"));
                resumen.setVentasPresenciales(rs.getDouble("ventas_presenciales"));
                resumen.setTotalCombinado(rs.getDouble("total_combinado"));
                return resumen;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return new DashboardResumen();
    }
}
