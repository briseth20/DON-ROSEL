package org.example.model;

public class Producto {
    private int id;
    private String nombre;
    private String descripcion;
    private double precio;
    private int stock;
    private int idCategoria; // 1 para Café, 2 para Cacao [cite: 12, 13]
    private String tostado;  // Atributo específico para variedades de café [cite: 12]
    private String peso;    // Filtro por peso planeado [cite: 12]
    private String imagenUrl;
    private boolean esVisible;
    private String imagen;// Para el control de visibilidad del admin// [cite: 37]
    private String tipo;

    // Constructor vacío (necesario para frameworks)
    public Producto() {}

    // Getters y Setters (Usa Alt + Insert en IntelliJ para generarlos rápido)
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }

    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }

    public boolean isEsVisible() { return esVisible; }
    public void setEsVisible(boolean esVisible) { this.esVisible = esVisible; }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(int idCategoria) {
        this.idCategoria = idCategoria;
    }

    public String getTostado() {
        return tostado;
    }

    public void setTostado(String tostado) {
        this.tostado = tostado;
    }

    public String getPeso() {
        return peso;
    }

    public void setPeso(String peso) {
        this.peso = peso;
    }

    public String getImagenUrl() {
        return imagenUrl;
    }

    public void setImagenUrl(String imagenUrl) {
        this.imagenUrl = imagenUrl;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}

