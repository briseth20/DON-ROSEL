package org.example.model;

public class Carrito {
    private int item;
    private int idProducto;
    private String nombre;
    private String peso;
    private double precioUnitario;
    private int cantidad;
    private double subTotal;

    public Carrito() {}

    // GETTERS
    public int getItem() { return item; }
    public int getIdProducto() { return idProducto; }
    public String getNombre() { return nombre; }
    public String getPeso() { return peso; }
    public double getPrecioUnitario() { return precioUnitario; }
    public int getCantidad() { return cantidad; }
    public double getSubTotal() { return subTotal; }
    public double getPrecio() { return precioUnitario; } // Alias para compatibilidad

    // SETTERS
    public void setItem(int item) { this.item = item; }
    public void setIdProducto(int idProducto) { this.idProducto = idProducto; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setPeso(String peso) { this.peso = peso; }
    public void setPrecioUnitario(double precioUnitario) { this.precioUnitario = precioUnitario; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }
    public void setSubTotal(double subTotal) { this.subTotal = subTotal; }
}