package org.example.model;

public class DashboardResumen {
    private double ventasWeb;
    private double ventasPresenciales;
    private double totalCombinado;

    public double getVentasWeb() { return ventasWeb; }
    public void setVentasWeb(double ventasWeb) { this.ventasWeb = ventasWeb; }

    public double getVentasPresenciales() { return ventasPresenciales; }
    public void setVentasPresenciales(double ventasPresenciales) { this.ventasPresenciales = ventasPresenciales; }

    public double getTotalCombinado() { return totalCombinado; }
    public void setTotalCombinado(double totalCombinado) { this.totalCombinado = totalCombinado; }
}
