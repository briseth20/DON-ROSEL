package org.example.model;

import java.io.Serializable;
import java.sql.Timestamp; // Para la fecha de la BD

public class Usuario implements Serializable {
    private int id_usuario;
    private String nombre;
    private String correo;
    private String password;
    private String rol;
    private Timestamp fecha_registro;

    public Usuario() {}

    // Getters y Setters que NO fallan
    public int getId_usuario() { return id_usuario; }
    public void setId_usuario(int id_usuario) { this.id_usuario = id_usuario; }

    public int getId() { return id_usuario; } // Alias para Servlets
    public void setId(int id) { this.id_usuario = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getRol() { return rol; }
    public void setRol(String rol) { this.rol = rol; }

    public Timestamp getFecha_registro() { return fecha_registro; }
    public void setFecha_registro(Timestamp fecha_registro) { this.fecha_registro = fecha_registro; }
}