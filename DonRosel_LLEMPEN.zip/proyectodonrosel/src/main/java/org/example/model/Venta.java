package org.example.model;

public class Venta {
    private int idVenta;
    private Integer idUsuario;
    private double montoTotal;
    private String metodoPago;
    private String estado;
    private String fecha;
    private String nroOperacion;
    private String nombreTitular;
    private String direccionEnvio;
    private String telefono;
    private boolean esVentaExterna;

    public Venta() {}

    // GETTERS
    public int getIdVenta() { return idVenta; }
    public Integer getIdUsuario() { return idUsuario; }
    public double getMontoTotal() { return montoTotal; }
    public String getMetodoPago() { return metodoPago; }
    public String getEstado() { return estado; }
    public String getFecha() { return fecha; }
    public String getNroOperacion() { return nroOperacion; }
    public String getNombreTitular() { return nombreTitular; }
    public String getDireccionEnvio() { return direccionEnvio; }
    public String getTelefono() { return telefono; }
    public boolean isEsVentaExterna() { return esVentaExterna; }

    // SETTERS
    public void setIdVenta(int idVenta) { this.idVenta = idVenta; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }
    public void setMontoTotal(double montoTotal) { this.montoTotal = montoTotal; }
    public void setMetodoPago(String metodoPago) { this.metodoPago = metodoPago; }
    public void setEstado(String estado) { this.estado = estado; }
    public void setFecha(String fecha) { this.fecha = fecha; }
    public void setNroOperacion(String nroOperacion) { this.nroOperacion = nroOperacion; }
    public void setNombreTitular(String nombreTitular) { this.nombreTitular = nombreTitular; }
    public void setDireccionEnvio(String direccionEnvio) { this.direccionEnvio = direccionEnvio; }
    public void setTelefono(String telefono) { this.telefono = telefono; }
    public void setEsVentaExterna(boolean esVentaExterna) { this.esVentaExterna = esVentaExterna; }

}